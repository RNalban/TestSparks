package ae.zand.devops.views.corporate;

import ae.zand.devops.utils.Wait;
import ae.zand.devops.views.onboarding.UserSetupandRole;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CustomerUserSetup {
    protected final WebDriver driver;
    private final By continueBy = By.xpath("//*[@id=\"userSetupStart\"]");

    public CustomerUserSetup(WebDriver driver) {
        this.driver = driver;
        Wait.waitForPageToLoad(driver, continueBy);
    }
    public UserSetupandRole goTostartsetup(){
       driver.findElement(continueBy).click();
       Wait.waitForSpinner(driver, continueBy);
        return new UserSetupandRole(driver);
    }

}
