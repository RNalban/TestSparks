package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SaveForm {
    private final By saveButtonBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/div[3]/button[3]");
    private WebDriver driver;
    //private final By formDisplay = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > div.u-p-4.u-shape-card");
    public SaveForm(WebDriver driver) {
        this.driver= driver;
        Wait.waitForPageToLoad(driver, saveButtonBy);
    }
    public void clickOnSave(){
        driver.findElement(saveButtonBy).click();
    }

}
