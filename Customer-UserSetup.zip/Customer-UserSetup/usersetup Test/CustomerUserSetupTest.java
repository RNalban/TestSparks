package ae.zand.devops.onboarding;

import ae.zand.devops.Setup;
import ae.zand.devops.views.common.Login;
import ae.zand.devops.views.corporate.CustomerUserSetup;
import ae.zand.devops.views.onboarding.*;
import org.testng.annotations.Test;

public class CustomerUserSetupTest extends Setup {
    @Test
    public void startUserSetup(){
        Login login = new Login(driver);
        CustomerUserSetup customerUserSetup = login.loginCustomerUserSetup(CUSTOMER_USERNAME,CUSTOMER_PASSWORD);
        customerUserSetup.goTostartsetup();

    }
    @Test (dependsOnMethods = {"startUserSetup"})
    public void quickAddAuthoriser(){

       UserSetupandRole userSetupandRole = new UserSetupandRole(driver);
      QuickAddUser quickAddUser= userSetupandRole.quickaddauthoriser();
      quickAddUser.setAuthoriserType();
      quickAddUser.setAdminAcess();
      quickAddUser.setDailyapproval();
      quickAddUser.setDailydrawdown();
      quickAddUser.setTransactionLimit();
      quickAddUser.setPreviewandNextButtonBy();
      quickAddUser.createuser();
    }
    @Test (dependsOnMethods = {"startUserSetup"})
    public void addingInputterUser(){
      //  Login login = new Login(driver);
     //   CustomerUserSetup customerUserSetup = login.loginCustomerUserSetup(CUSTOMER_USERNAME,CUSTOMER_PASSWORD);
    UserSetupandRole userSetupandRole = new UserSetupandRole(driver);
            //customerUserSetup.goTostartsetup();
        AddNewUser addNewUser = userSetupandRole.addnewuser();
        addNewUser.enterEmailAddress("nalban786@gmail.com");
        addNewUser.enterUserType("Inputter");
        addNewUser.uploadEmiratesIDBy(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/KhoulaID.jpg");
        addNewUser.setMobNumberBy("+971564506145");
        addNewUser.setGenderBy();
        addNewUser.setTransactionLimitBy("999999999");
        addNewUser.setNationalBy("United Arab Emirates");
       PreviewPage previewPage= addNewUser.setPreviewButtonBy();
       previewPage.clickonNext();
      // previewPage.setAllOptions();
      // previewPage.setAddgroupnameBy(RandomStringUtils.randomAlphabetic(7));
        previewPage.createuser();

    }

    @Test (dependsOnMethods = {"startUserSetup"})
    public void addingAdminUser(){
        UserSetupandRole userSetupandRole = new UserSetupandRole(driver);
        AddNewUser addNewUser = userSetupandRole.addnewuser();
        addNewUser.enterEmailAddress("r.murad@gmail.com");
        addNewUser.enterUserType("Admin");
        addNewUser.uploadEmiratesIDBy(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/AGP RASHID Murad EID 2020 1.jpg");
        addNewUser.setMobNumberBy("+971561234567");
        addNewUser.setMaleGenderBy();
        addNewUser.setNationalBy("United Arab Emirates");
        SaveForm saveForm = addNewUser.adminPreviewandSave();
        saveForm.clickOnSave();
    }
    @Test (dependsOnMethods = {"startUserSetup"})
    public void AddNewRule(){
        UserSetupandRole userSetupandRole = new UserSetupandRole(driver);
        AuthorityMatrix authorityMatrix = userSetupandRole.submit();
        authorityMatrix.addingnewRule();
        authorityMatrix.setCheckconditonBy();
        authorityMatrix.Finish();


    }

}
