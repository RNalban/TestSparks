package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AddNewUser {
    protected final WebDriver driver;
    private final By emailBy = By.cssSelector("input#email");
    private final By userTypeBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/form/div/div[1]/span[2]/div/div/div/div[1]/div[2]");
    private final By inputUserType = By.cssSelector("input#userType");
    private final By inputEmiratesIDBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(2) > span:nth-child(4) > div > div > div > div > div > div > div > input");
    private final By emiratesSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(2) > span:nth-child(4) > div > div > div > div > div > div.el-loading-mask > div");
    private final By inputbackEmirateBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(2) > span:nth-child(5) > div > div > div > div > div > div > div > input");
    private final By emiratesbackSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(2) > span:nth-child(5) > div > div > div > div > div > div.el-loading-mask > div");
    private final By transactionLimitBy = By.cssSelector("input#perTransactionLimit");
    private final By genderBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(1) > span:nth-child(6) > div > div > div > div > label.el-radio._radio.is-checked > span.el-radio__input.is-checked");
    private final By nationalBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(1) > span:nth-child(5) > div > div > div > div.multiselect.is--light > div.multiselect__tags");
    private final By inputNationality = By.cssSelector("input#nationality");
    private final By mobNumberBy = By.cssSelector("input#phoneNumber");
    private final By previewButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-my-4 > button.el-button.u-ml-3.el-button--primary._button");
    private final By nextButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-my-4 > button.el-button.u-ml-3.el-button--primary._button");

    public AddNewUser(WebDriver driver) {
        this.driver=driver;
       // Wait.waitForPageToLoad(driver, emailBy);
        Wait.waitForPageToLoad(driver, userTypeBy);
    }

    public void enterEmailAddress(String email){

        driver.findElement(emailBy).sendKeys(email + Keys.ENTER);
    }
    public void  enterUserType(String userType){

        driver.findElement(userTypeBy).click();
        driver.findElement(inputUserType).sendKeys(userType + Keys.ENTER);
    }

    public void setMobNumberBy(String mobNumber){
        driver.findElement(mobNumberBy).clear();
        driver.findElement(mobNumberBy).sendKeys(mobNumber);}

    public void setNationalBy(String nationality){
        driver.findElement(nationalBy).click();
        driver.findElement(inputNationality).sendKeys(nationality + Keys.ENTER);
    }

    public void setGenderBy(){driver.findElement(genderBy).click();}

    public void uploadEmiratesIDBy(String path){
        driver.findElement(inputEmiratesIDBy).sendKeys(path);
        Wait.waitForSpinner(driver, emiratesSpinner);
        driver.findElement(inputbackEmirateBy).sendKeys(path);
        Wait.waitForSpinner(driver, emiratesbackSpinner);
    }
    public void setTransactionLimitBy(String limit){
        driver.findElement(transactionLimitBy).clear();
        driver.findElement(transactionLimitBy).sendKeys(limit);
    }
    public void previewAndnexButtonBy(){
        driver.findElement(previewButtonBy).click();
        Wait.waitForSpinner(driver, previewButtonBy);
        Wait.waitForPageToLoad(driver, nextButtonBy);
        driver.findElement(nextButtonBy).click();
    }





    
}
