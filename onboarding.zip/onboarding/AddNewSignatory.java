package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AddNewSignatory {
    protected final WebDriver driver;
    private final By loadmaskBy = By.cssSelector("div.el-loading-mask");
    private final By nameBy = By.cssSelector("#signatories\\[1\\]\\.name");
    private final By genderBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[2]/span/div/div/div/div/label[2]/span[1]/span");
    private final By emailBy = By.cssSelector("#signatories\\[1\\]\\.emailAddress");
    private final By designationBy = By.cssSelector("#signatories\\[1\\]\\.designation");
    private final By birthdateBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(6) > span > div > div > div > div > input");//("#signatories\\[1\\]\\.placeOfBirth");
    private final By inputBirthplace = By.cssSelector("#signatories\\[1\\]\\.placeOfBirth");
    private final By birthplaceBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags");
    private final By option1By = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[1]/span/div/div/div/div/label[2]/span[1]");
    private final By option2By = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[2]/span/div/div/div/div/label[2]/span[1]");
    private final By option3By = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[3]/span/div/div/div/div/label[2]/span[1]");
    private final By dualCitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[12]/span/div/div/div/div/label[2]/span[1]");
    private final By nationalityBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(7) > span > div > div > div > div > div.multiselect__tags");
    private final By inputnationality = By.cssSelector("#signatories\\[1\\]\\.mainNationality\\.nationality");
    private final By mobilenumber = By.cssSelector("#signatories\\[1\\]\\.mobileNumber");
    //private final By birthplaceoption = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[5]/span/div/div/div/div/div[3]/ul/li[1]/span");
    private final By birthplacespinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    //private final By uploademiratesfrontBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div:nth-child(2) > span > div > div > div > div > div > div > div > div > button");
    private final By inputemiratesfrontBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div:nth-child(2) > span > div > div > div > div > div > div > div > input");
    //private final By uploademiratesbackBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div:nth-child(3) > span > div > div > div > div > div > div > div > div > button");
    private final By inputemiratesbackBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div:nth-child(3) > span > div > div > div > div > div > div > div > input");
    private final By emiratesfrontspinner = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[2]/div[2]/span/div/div/div/div/div/div[3]");
    private final By emiratesbackspinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div:nth-child(3) > span > div > div > div > div > div > div.el-loading-mask");
    private final By nextButton = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div._onboarding-footer.u-mb-3.u-pr-4 > div > button.el-button.el-button--primary._button");

        public AddNewSignatory(WebDriver driver) {
        this.driver=driver;
       // Wait.waitForSpinner(driver, loadmaskBy);
        Wait.waitForPageToLoad(driver, nameBy);
    }
    public void setuploadEmiratesBy(){

        driver.findElement(inputemiratesfrontBy).sendKeys("C:\\Users\\Rehmat.Nalban\\Desktop\\automated-test-framework (1)\\automated-test-framework\\coral-automation-test\\src\\test\\resources\\documents\\MRBADAR ID.jpg");
        Wait.waitForSpinner(driver, emiratesfrontspinner);
        driver.findElement(inputemiratesbackBy).sendKeys("C:\\Users\\Rehmat.Nalban\\Desktop\\automated-test-framework (1)\\automated-test-framework\\coral-automation-test\\src\\test\\resources\\documents\\MRBADAR ID.jpg");
        Wait.waitForSpinner(driver, emiratesbackspinner);
    }


    public void selectGender(){
        driver.findElement(genderBy).click();
    }
    public void EntermobNumber(){
        driver.findElement(mobilenumber).sendKeys("+971501234567" + Keys.ENTER);
    }
    public void addEmail(String email){
        driver.findElement(emailBy).sendKeys(email + Keys.ENTER);
    }
    //public void birthdate(String date){
        //driver.findElement(birthdateBy).sendKeys(date + Keys.ENTER); }
    public void birthplace(String birthplace){
        Wait.waitForSpinner(driver, birthplacespinner);
        driver.findElement(birthplaceBy).click();
        driver.findElement(inputBirthplace).sendKeys(birthplace + Keys.ENTER);
        // Wait.waitForDrawer(driver, birthplaceoption);
        //driver.findElement(birthplaceoption).click();

    }
    public void addDesignation(String designation){
        driver.findElement(designationBy).sendKeys(designation + Keys.ENTER);
    }


    public void setNationality(String nationality){
        Wait.waitForSpinner(driver, emiratesbackspinner);
        driver.findElement(nationalityBy).click();
        driver.findElement(inputnationality).sendKeys(nationality + Keys.ENTER);
    }
    public void setDualCitizenBy(){
        driver.findElement(dualCitizenBy).click();
    }

    public void otherDetails(){
        driver.findElement(option1By).click();
        driver.findElement(option2By).click();
        driver.findElement(option3By).click();
    }

    public OwnershipDetails submit(){

        driver.findElement(nextButton).click();
        Wait.waitForSpinner(driver, nextButton);
        return new OwnershipDetails(driver);
    }

}
