package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;


public class CompanyFillInformation {
    protected final WebDriver driver;
    private final By loadingmaskBy = By.cssSelector("div.el-loading-mask");
     private final By enterdateincorpBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/div[1]/div[1]/div/div[6]/span/div/div/div/div/input");
    private final By placeincorp = By.xpath("//input[@id='company.placeOfIncorporation']");
    private final By companynumber = By.xpath("//input[@id='company.phoneNumber']");
    private final By countryspinner= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(7) > span:nth-child(2) > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By countryoption = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(7) > span:nth-child(2) > div > div > div > div > div.multiselect__tags");
    private final By inputcountry = By.cssSelector("#company\\.countryOfIncorporation");
    private final By countryoptiondropBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(7) > span:nth-child(2) > div > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(1) > span");
    private final By emiratespinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(8) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By emirateoption = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(8) > span > div > div > div > div > div.multiselect__tags");
    private final By inputemirate = By.cssSelector("#company\\.emirate");
    private final By emiratedropdownBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(8) > span > div > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(2) > span");
    private final By formationspinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(9) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By inputformation = By.cssSelector("#company\\.formationType");
    private final By formationoption = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/div[1]/div[1]/div/div[9]/span/div/div/div/div/div[2]");
    private final By formationdropdownBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(9) > span > div > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(1) > span");
    private final By licensespinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(10) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By licenseinput= By.cssSelector("#company\\.licenseIssuingAuthority");
    private final By licenseoption = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(10) > span > div > div > div > div > div.multiselect__tags");
    private final By licensedropdown = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(10) > span > div > div > div > div > div.multiselect__content-wrapper > ul > li.multiselect__element > span");
    private final By inputentity = By.cssSelector("#company\\.entityType");
    private final By entityoption = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(11) > span > div > div > div > div > div.multiselect__tags");
    private final By entityspinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(11) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By entitydropdown = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(11) > span > div > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(4) > span");
    private final By registeredaddressBy = By.xpath("//*[@id=\"registeredAddress.address\"]");
    private final By registeredPOBOX = By.xpath("//*[@id=\"registeredAddress.poBox\"]");
    private final By saveOptionBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div/div/button[1]");
    private final By savespinnerBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div > div > button.el-button.el-button--button._button > i");
    private final By nextButton = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div/div/button[2]");
    private final By registeredcountryBy = By.cssSelector("#country > span > div > div > div > div > div.multiselect__tags");
    private final By registeredcountryspinner = By.cssSelector("#country > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By inputregcountry = By.cssSelector("#registeredAddress\\.country");
    private final By regcountrydropdownBy =By.cssSelector("#country > span > div > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(1) > span");
    private final By regemiratesBy = By.cssSelector("div#registered-address > div > div#emirateOrState > span > div > div > div > div > div.multiselect__tags");
    private final By regemiratesspinnerBy = By.cssSelector("div#registered-address > div > div#emirateOrState > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By regemiratedropdownBy = By.cssSelector("div#registered-address > div > div#emirateOrState > span > div > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(3) > span");
    private final By inputregemirateBy = By.cssSelector("#registeredAddress\\.emirateOrState");
    private final By inputregCity = By.cssSelector("#registeredAddress\\.cityCode");
    private final By regCityoption = By.cssSelector("div#registered-address > div > div#city > span > div > div > div > div > div.multiselect__tags");
    private final By regCityspinner = By.cssSelector("div#registered-address > div > div#city > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By regCitydropdownBy = By.cssSelector("div#registered-address > div > div#city > span > div > div > div > div > div.multiselect__content-wrapper > ul > li.multiselect__element > span");
    private final By getcountry= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div:nth-child(1) > div:nth-child(1) > div > div:nth-child(7) > span:nth-child(2) > div > div > div > div > div.multiselect__tags > span");
    private final By uploadPOA = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div._onboarding-requests__right-column.el-col.el-col-24.el-col-xs-24.el-col-md-12 > div.app-onboarding-container.u-display-flex.u-flex-direction-column.u-mb-5 > div:nth-child(4) > div:nth-child(2) > span > div > div > div > div > div > div > div > input");
    private final By POAspinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.el-row > div._onboarding-requests__right-column.el-col.el-col-24.el-col-xs-24.el-col-md-12 > div.app-onboarding-container.u-display-flex.u-flex-direction-column.u-mb-5 > div:nth-child(4) > div:nth-child(2) > span > div > div > div > div > div > div.el-loading-mask > div");
    private final By contactNameBy = By.cssSelector("#contactPersons\\[0\\]\\.name");
    private final By contactMobBy = By.cssSelector("#contactPersons\\[0\\]\\.mobileNumber");
    private final By contactEmailBy = By.cssSelector("#contactPersons\\[0\\]\\.emailAddress");
    private final By dualcitizenBy = By.xpath("//*[@id=\"contact-person-0\"]/div/div[9]/span/div/div/div/div/label[2]/span[1]");
    private final By inputbirthdateBy = By.xpath("//*[@id=\"contact-person-0\"]/div/div[6]/span/div/div/div/div/input");
    private final By countryresidence = By.cssSelector("#contact-person-0 > div > div:nth-child(7) > span > div > div > div > div > div.multiselect__tags");
    private final By inputcountryresidence = By.xpath("//*[@id=\"contactPersons[0].countryOfResidence\"]");
    private final By nationalityBy = By.xpath("//*[@id=\"contact-person-0\"]/div/div[8]/span/div/div/div/div/div[2]");
    private final By inputnationality = By.xpath("//*[@id=\"contactPersons[0].nationality\"]");
    private final By inputdesignationBy = By.cssSelector("#contactPersons\\[0\\]\\.designation");

    public CompanyFillInformation(WebDriver driver) {
        this.driver=driver;
       Wait.waitForPageToLoad(driver, companynumber);
        Wait.waitForSpinner(driver, loadingmaskBy);
    }

    public void enterIncorporationDate(String incorpdate){

        driver.findElement(enterdateincorpBy).sendKeys(incorpdate + Keys.ENTER);
    }
    public void placeofIncorporation(String place){

        driver.findElement(placeincorp).clear();
        driver.findElement(placeincorp).sendKeys(place);
    }
    public void countryincorporation(String country){
        //Wait.waitForPageToLoad(driver, countryoption);
        //Wait.waitForSpinner(driver, countryspinner);
        driver.findElement(countryoption).click();
        driver.findElement(inputcountry).clear();
        driver.findElement(inputcountry).sendKeys(country + Keys.ENTER);
        //driver.findElement(countryoptiondropBy).click();
    }

    public void emiratesIncorporation(String emirates){
        //Wait.waitForPageToLoad(driver, emirateoption);
       // Wait.waitForSpinner(driver, emiratespinner);
        driver.findElement(emirateoption).click();
        driver.findElement(inputemirate).sendKeys(emirates + Keys.ENTER);
       // Wait.waitForDrawer(driver, emiratedropdownBy);
        //driver.findElement(emiratedropdownBy).click();

    }

    public void formationType( String formation){
        Wait.waitForSpinner(driver, formationspinner);
        driver.findElement(formationoption).click();
        driver.findElement(inputformation).sendKeys(formation + Keys.ENTER);
        //Wait.waitForDrawer(driver, formationdropdownBy);
        //driver.findElement(formationdropdownBy).click();
    }
    public void licenseType(String license){
        Wait.waitForSpinner(driver, licensespinner);
        driver.findElement(licenseoption).click();
        driver.findElement(licenseinput).sendKeys(license + Keys.ENTER);
        //Wait.waitForDrawer(driver, licensedropdown);
       // driver.findElement(licensedropdown).click();
    }
    public void entityType(String entity){
       // Wait.waitForSpinner(driver, entityspinner);
        driver.findElement(entityoption).click();
        driver.findElement(inputentity).sendKeys(entity + Keys.ENTER);
        //Wait.waitForDrawer(driver, entitydropdown);
      //  driver.findElement(entitydropdown).click();
    }

    public void registeredCountry(String registeredCountry){
       // Wait.waitForSpinner(driver, registeredcountryspinner);
        driver.findElement(registeredcountryBy).click();
       // driver.findElement(inputregcountry).clear();
        driver.findElement(inputregcountry).sendKeys(registeredCountry + Keys.ENTER);
       // Wait.waitForDrawer(driver, regcountrydropdownBy);
     // driver.findElement(regcountrydropdownBy).click();
    }
    public void registeredEmirates(String registeredEmirate){
       // Wait.waitForSpinner(driver, regemiratesspinnerBy);
        driver.findElement(regemiratesBy).click();
       driver.findElement(inputregemirateBy).sendKeys(registeredEmirate + Keys.ENTER);
        //driver.findElement(regemiratedropdownBy).click();
    }
    public void registeredCity(String registeredCity){
        Wait.waitForSpinner(driver, regCityspinner);
        driver.findElement(regCityoption).click();
        driver.findElement(inputregCity).sendKeys(registeredCity + Keys.ENTER);
       // Wait.waitForDrawer(driver, regCitydropdownBy);
       // driver.findElement(regCitydropdownBy).click();
    }

    public void companyContactNumber(String contact){
       // Wait.waitForPageToLoad(driver, companynumber);
        driver.findElement(companynumber).clear();
        driver.findElement(companynumber).sendKeys(contact);
    }

    public void setRegisteredaddressBy(String address){
     //   Wait.waitForPageToLoad(driver, registeredaddressBy);
        driver.findElement(registeredaddressBy).clear();
        driver.findElement(registeredaddressBy).sendKeys(address);
    }


    public void setRegisteredPOBOX(String POBox){
       // Wait.waitForPageToLoad(driver, registeredPOBOX);
        driver.findElement(registeredPOBOX).clear();
        driver.findElement(registeredPOBOX).sendKeys(POBox);
    }
    public void supportingDocuments(String path){
        driver.findElement(uploadPOA).sendKeys(path);
        Wait.waitForSpinner(driver, POAspinner);
    }

    public void contactName(String name){
        driver.findElement(contactNameBy).clear();
        driver.findElement(contactNameBy).sendKeys(name);
    }

    public void contactmobile(String mobile){
        driver.findElement(contactMobBy).clear();
        driver.findElement(contactMobBy).sendKeys(mobile); }

    public void contactEmail(String email){
        driver.findElement(contactEmailBy).clear();
        driver.findElement(contactEmailBy).sendKeys(email );
    }

    public void setDesignation(String role){
        driver.findElement(inputdesignationBy).clear();
        driver.findElement(inputdesignationBy).sendKeys(role + Keys.ENTER);
    }
    public void setCountryresidence(){
        driver.findElement(countryresidence).click();
        driver.findElement(inputcountryresidence).sendKeys("United Arab Emirates" + Keys.ENTER);
    }

    public void setNationalityBy(){
        driver.findElement(nationalityBy).click();
        driver.findElement(inputnationality).sendKeys("United Arab Emirates" + Keys.ENTER);
    }

    public void setDualCitizen(){
        driver.findElement(dualcitizenBy).click();
    }

    public void contactbirthdate(){
        driver.findElement(inputbirthdateBy).sendKeys("10-May-1998" + Keys.ENTER);
    }
    public void updateInformation(){
       // Wait.waitForPageToLoad(driver, saveOptionBy );
        driver.findElement(saveOptionBy).click();
        Wait.waitForSpinner(driver, savespinnerBy);
    }

    public TaxInformation submit(){
       // Wait.waitForPageToLoad(driver, nextButton);
        driver.findElement(nextButton).click();
        Wait.waitForSpinner(driver, nextButton);
        return new TaxInformation(driver);

    }

}
