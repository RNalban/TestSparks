package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class QuickAddUser {
    protected final WebDriver driver;
    private final By usertypeBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/form/div/div[2]/span[2]/div/div/div/div[1]/div[2]");
    private final By inputUser= By.cssSelector("#userType");
    private final By setAdminacessBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/form/div/div[2]/span[4]/div/div/div/div/label[1]/span[1]");
    private final By dailyapprovalBy = By.cssSelector("input#dailyApprovalLimit");
    private final By dailydrawdownBy = By.cssSelector("input#dailyDrawdownLimit");
    private final By transactionLimitBy = By.cssSelector("input#perTransactionLimit");
    private final By previewButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-my-4 > button.el-button.u-ml-3.el-button--primary._button > span");
    private final By nextButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-my-4 > button.el-button.u-ml-3.el-button--primary._button");
    private final By createUserBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-my-4 > button.el-button.u-ml-3.el-button--primary._button");

    public QuickAddUser(WebDriver driver) {
        this.driver = driver;
        Wait.waitForPageToLoad(driver, usertypeBy);
    }
    public void setAuthoriserType(){

        driver.findElement(usertypeBy).click();
        driver.findElement(inputUser).sendKeys("Authoriser" + Keys.ENTER);
    }


    public void setAdminAcess(){
        driver.findElement(setAdminacessBy).click();

    }
    public void setDailyapproval(){
        //driver.findElement(dailyapprovalBy).clear();
        Wait.waitForDrawer(driver, dailyapprovalBy);
        driver.findElement(dailyapprovalBy).sendKeys("999999999999" );
    }

    public void setDailydrawdown(){
        //driver.findElement(dailydrawdownBy).clear();
        driver.findElement(dailydrawdownBy).sendKeys("999999999999" );
    }
    public void setTransactionLimit(){
        //driver.findElement(transactionlimit).clear();
        driver.findElement(transactionLimitBy).sendKeys("999999999999" );
    }

    public void setPreviewandNextButtonBy(){

        driver.findElement(previewButtonBy).click();   //click on preview after filling the remaining fields
        //Wait.waitForSpinner(driver, previewButtonBy);
        Wait.waitForPageToLoad(driver, nextButtonBy); // goes to page where form is reviewed  which waiting for the next button
        driver.findElement(nextButtonBy).click();
    }

    public void createuser(){

        Wait.waitForPageToLoad(driver, createUserBy); // goes to the page where user products are reviewed, wait for that element and click on it.
        driver.findElement(createUserBy).click();
        Wait.waitForSpinner(driver, createUserBy);
    }
}
