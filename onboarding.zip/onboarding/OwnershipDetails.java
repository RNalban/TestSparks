package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OwnershipDetails {
    protected final WebDriver driver;
    private final By shareholderloadingmaskBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div:nth-child(1) > div.el-loading-mask");
    private final By signatoriesloadingmaskBy = By.cssSelector("#signatories > div.el-loading-mask");
    private final By beneficialownersloadingmaskby = By.cssSelector("#beneficial-owners > div.el-loading-mask");
    private final By boardmembersloadingmaskby = By.cssSelector("#board-members > div.el-loading-mask");
    private final By optionsBy =  By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[2]/div[4]/div[2]/table/tbody/tr[1]/td[5]/div/span/div[2]/button/i");
    private final By viewDetails = By.xpath("(//*[@id=\"SHAREHOLDER_2_viewEdit\"])[2]");
    private final By removeBy = By.xpath("(//*[text()=' Remove '])[8]");
    private final By viewDetailSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div.el-loading-mask");
    private final By addsignatoryBy = By.cssSelector("#signatories > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > div > div > div.multiselect__tags");
    private final By getAddsignatoryBy =By.xpath("//*[@id=\"signatories\"]/div[1]/div/div/div/div[3]/ul/li[2]/span/label/span/span");
    private final By addnewsignatory = By.cssSelector("#signatories > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > button");
    private final By addbeneficialBy  = By.cssSelector("#beneficial-owners > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > div > div > div.multiselect__tags");
    private final By getBeneficialBy = By.xpath("//*[@id=\"beneficial-owners\"]/div[1]/div/div/div/div[3]/ul/li[1]/span");
    private final By addnewBeneficiaryBy = By.cssSelector("#beneficial-owners > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > button");
    private final By addboardmemberBy= By.cssSelector("#board-members > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > div > div > div.multiselect__tags");
    private final By getAddboardmemberBy = By.cssSelector("#board-members > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(1) > span");
    private final By addnewboardmemberBy = By.cssSelector("#board-members > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > button");
    private final By nextButtonBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[5]/div/button");
    public OwnershipDetails(WebDriver driver) {
        this.driver = driver;
        Wait.waitForSpinner(driver, shareholderloadingmaskBy);
      Wait.waitForSpinner(driver, signatoriesloadingmaskBy);
       Wait.waitForSpinner(driver, beneficialownersloadingmaskby);
        Wait.waitForSpinner(driver, boardmembersloadingmaskby );
        Wait.waitForPageToLoad(driver, optionsBy);
    }

    public void viewdetails(){
        driver.findElement(optionsBy).click();
       Wait.waitForDrawer(driver, viewDetails );
       driver.findElement(viewDetails).click();
        //Wait.waitForSpinner(driver, viewDetailSpinner);
        }

    public void addSignatoryfromExistingShareholder(){
        driver.findElement(addsignatoryBy).click();
        Wait.waitForDrawer(driver, getAddsignatoryBy);
        driver.findElement(getAddsignatoryBy).click();
    }

    public AddNewSignatory addsignatoryuser(){
        driver.findElement(addnewsignatory).click();
        return new AddNewSignatory(driver);
    }

    public void addBeneficialFromExistingShareholder(){
        driver.findElement(addbeneficialBy).click();
        Wait.waitForDrawer(driver, getBeneficialBy);
        driver.findElement(getBeneficialBy).click();
    }
    public AddNewBeneficialOwner addbeneficialuser(){
        driver.findElement(addnewBeneficiaryBy).click();
        return new AddNewBeneficialOwner(driver);
    }
    public void addBoardMembers(){
        driver.findElement(addboardmemberBy).click();
        Wait.waitForDrawer(driver, getAddboardmemberBy);
        driver.findElement(getAddboardmemberBy).click();

    }
    public AddBoardMember addnewboardmember(){
        driver.findElement(addnewboardmemberBy).click();
        return new AddBoardMember(driver);
    }

    public CustomerVerify nextpage(){
        driver.findElement(nextButtonBy).click();
        Wait.waitForSpinner(driver, nextButtonBy);
        return new CustomerVerify(driver);
    }
}
