package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.checkerframework.checker.units.qual.K;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import java.security.Key;

public class AddBoardMember {
    protected final WebDriver driver;
    private final By loadingmaskBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div.el-loading-mask");
    private final By nameBy = By.cssSelector("#boardMembers\\[1\\]\\.name");
    private final By inputpassportBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[2]/div/span/div/div/div/div/div/div/div/input");
    private final By passportspinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div > span > div > div > div > div > div > div.el-loading-mask > div");
    private final By countryresidenceoption= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(8) > span > div > div > div > div > div.multiselect__tags");
    private final By inputresidence= By.cssSelector("#boardMembers\\[1\\]\\.countryOfResidence");
    private final By residencespinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(8) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By mobilenumberBy = By.cssSelector("#boardMembers\\[1\\]\\.mobileNumber");
    private final By emailaddressBy = By.cssSelector("#boardMembers\\[1\\]\\.emailAddress");
    private final By birthplaceBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags");
    private final By inputbirthplace = By.cssSelector("#boardMembers\\[1\\]\\.placeOfBirth");
    private final By nationalityBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(7) > span > div > div > div > div > div.multiselect__tags");
    private final By inputnationality = By.cssSelector("#boardMembers\\[1\\]\\.mainNationality\\.nationality");
    private final By issuedateBy= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(11) > span > div > div > div > div > input");
    private final By authissueBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(10) > span > div > div > div > div > div.multiselect__tags");
    private final By inputauthissueBy = By.cssSelector("#boardMembers\\[1\\]\\.mainNationality\\.passportIssuanceAuthority");
    private final By dualcitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[13]/span/div/div/div/div/label[2]/span[1]");
    private final By UScitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[1]/span/div/div/div/div/label[2]/span[1]");
    private final By taxResidentBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[2]/span/div/div/div/div/label[2]/span[1]");
    private final By othertaxresidentBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[3]/span/div/div/div/div/label[2]/span[1]");
    private final By nextButtonBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[2]/div/button[3]");
    public AddBoardMember(WebDriver driver) {
        this.driver = driver;
       // Wait.waitForSpinner(driver, loadingmaskBy);
        Wait.waitForPageToLoad(driver, nameBy);
    }
    public void countryofresidence(){
        driver.findElement(countryresidenceoption).click();
        driver.findElement(inputresidence).sendKeys("Oman" + Keys.ENTER);
    }
    public void uploadPassport(){
        driver.findElement(inputpassportBy).sendKeys("C:\\Users\\Rehmat.Nalban\\Desktop\\automated-test-framework (1)\\automated-test-framework\\coral-automation-test\\src\\test\\resources\\documents\\ALWAHDANIABADARPassportOman.jpg");
        Wait.waitForSpinner(driver, passportspinner);
    }

    public void enterMobile(String mobile){
        Wait.waitForSpinner(driver,passportspinner);
        driver.findElement(mobilenumberBy).sendKeys(mobile + Keys.ENTER);
    }
    public void enterEmail(String email){
        driver.findElement(emailaddressBy).sendKeys(email + Keys.ENTER);
    }

    public void setBirthplace(String birthplace){
        driver.findElement(birthplaceBy).click();
        driver.findElement(inputbirthplace).sendKeys(birthplace + Keys.ENTER);

    }

    public void setNationality(String nationality){
        driver.findElement(nationalityBy).click();
        driver.findElement(inputnationality).sendKeys(nationality+ Keys.ENTER);
    }
    public void enterIssuedate(){
        driver.findElement(issuedateBy).sendKeys("13-Apr-2019"+Keys.ENTER);
    }
    public void enterAuthissue(){
        driver.findElement(authissueBy).click();
        driver.findElement(inputauthissueBy).sendKeys("United Arab Emirates" + Keys.ENTER);
    }
    public void setDualcitizenBy(){
        driver.findElement(dualcitizenBy).click();
    }
    public void selectOptions(){
        driver.findElement(UScitizenBy).click();
        driver.findElement(taxResidentBy).click();
        driver.findElement(othertaxresidentBy).click();
    }
    public OwnershipDetails submit(){
        driver.findElement(nextButtonBy).click();
        Wait.waitForSpinner(driver, nextButtonBy);
        return new OwnershipDetails(driver);
    }
}

