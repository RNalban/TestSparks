package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class TaxInformation {
    protected final WebDriver driver;
    private final By loadingmaskBy = By.cssSelector("div.el-loading-mask");
    private final By selectUSregistered = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[1]/span/div/div/div/div/label[2]/span[1]/span"); //By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.app-onboarding-container.u-display-flex.u-flex-direction-column > form > div:nth-child(1) > span > div > div > div > div > label.el-radio._radio.is-checked > span.el-radio__input.is-checked > input");
    private final By selectTaxreg = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[2]/span/div/div/div/div/label[2]/span[1]");
    private final By FFIBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[4]/span/div/div/div/div/label[2]/span[1]");
    private final By GGINBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[9]/span/div/div/div/div/label[2]/span[1]");
    private final By sanctionBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[10]/div[1]/span/div/div/div/div/label[2]/span[1]");
    private final By subsiadiarysanctionBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[10]/div[2]/span/div/div/div/div/label[2]/span[1]/span");
    private final By tradesanctionBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[10]/div[3]/span/div/div/div/div/label[2]/span[1]");
    private final By exportgoodBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[10]/div[4]/span/div/div/div/div/label[2]/span[1]/span");
    private final By remitmoneytosancBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[10]/div[5]/span/div/div/div/div/label[2]/span[1]/span");
    private final By auditedsancBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div[1]/form/div[10]/div[6]/span/div/div/div/div/label[2]/span[1]/span");
    private final By nextButton = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div > div > button.el-button.el-button--primary._button");
    private final By saveButton= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div > div > button.el-button.el-button--button._button");
    private final By saveSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div > div > button.el-button.el-button--button._button > i");
    private final By ffiStatusBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.app-onboarding-container.u-display-flex.u-flex-direction-column > form > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags");
    private final By inputffiBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.app-onboarding-container.u-display-flex.u-flex-direction-column > form > div:nth-child(5) > span > div > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(4) > span > span");
    private final By nextspinner= By.cssSelector("div > span > div > div > button.el-button.el-button--primary.is-loading._button > i");
    private final By nffestatusBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.app-onboarding-container.u-display-flex.u-flex-direction-column > form > div:nth-child(6) > span > div > div > div > div > div.multiselect__tags");
    private final By nffestatusoption = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > form > div.app-onboarding-container.u-display-flex.u-flex-direction-column > form > div:nth-child(6) > span > div > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(5) > span");
    private final By sponsernameBy = By.xpath("//*[@id=\"companyFATCA.sponsorName\"]");
    private final By sponsornumberBy = By.xpath("//*[@id=\"companyFATCA.sponsorNumber\"]");


    public TaxInformation( WebDriver driver) {
        this.driver= driver;
        Wait.waitForSpinner(driver, loadingmaskBy);
    }

    public void setSelectUSregistered(){
        driver.findElement(selectUSregistered).click();
    }

    public void setTaxRegisteration(){
        driver.findElement(selectTaxreg).click();
    }

    public void setFFIBy(){
        driver.findElement(FFIBy).click();
    }

    public void FFIReason(){
        driver.findElement(ffiStatusBy).click();
        Wait.waitForDrawer(driver, inputffiBy);
        driver.findElement(inputffiBy).click();
    }
    public void NFFEStatus(){
        driver.findElement(nffestatusBy).click();
        Wait.waitForDrawer(driver, nffestatusoption);
        driver.findElement(nffestatusoption).click();
    }
    public void setSponsername(){
        driver.findElement(sponsernameBy).sendKeys("Murad Baloushi" + Keys.ENTER);
    }
    public void setSponsornumber(){
        driver.findElement(sponsornumberBy).sendKeys("052461" + Keys.ENTER);
    }
    public void setGGINBy(){
        driver.findElement(GGINBy).click();
    }

    public void setSanctionBy(){
        driver.findElement(sanctionBy).click();
    }
    public void setSubsiadiarysanctionBy(){
        driver.findElement(subsiadiarysanctionBy).click();
    }

    public void setExportgoodBy(){
        driver.findElement(exportgoodBy).click();
    }

    public void setTradesanctionBy(){
        driver.findElement(tradesanctionBy).click();
    }

    public void setRemitmoneytosancBy(){
        driver.findElement(remitmoneytosancBy).click();
    }
    public void setAuditedsancBy(){
        driver.findElement(auditedsancBy).click();
    }

    public void updateform(){
        driver.findElement(saveButton).click();
        Wait.waitForSpinner(driver, saveSpinner);
    }
    public OwnershipDetails submit(){
        driver.findElement(nextButton).click();
        Wait.waitForSpinner(driver, nextButton);
        return new OwnershipDetails(driver);
        
    }


}
