package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AddNewBeneficialOwner {
    protected final WebDriver driver;
    private final By loadingmaskBy = By.cssSelector("div.el-loading-mask");
    private final By nameBy = By.xpath("//*[@id=\"beneficialOwners[1].name\"]");
    private final By countryofresidence = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(8) > span > div > div > div > div > div.multiselect__tags");
    private final By inputcountryofresidence = By.xpath("//*[@id=\"beneficialOwners[1].countryOfResidence\"]");
    private final By inputpassport = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div > span > div > div > div > div > div > div > div > input");
    private final By passportspinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div > span > div > div > div > div > div > div.el-loading-mask > div");
    private final By inputmobile = By.cssSelector("#beneficialOwners\\[1\\]\\.mobileNumber");
    private final By inputemail = By.cssSelector("#beneficialOwners\\[1\\]\\.emailAddress");
    private final By inputBirthplace = By.cssSelector("#beneficialOwners\\[1\\]\\.placeOfBirth");
    private final By birthplacespinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By birthplaceBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags");
    private final By issuanceauthority = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(10) > span > div > div > div > div > div.multiselect__tags");
    private final By inputissuanceBy = By.cssSelector("#beneficialOwners\\[1\\]\\.mainNationality\\.passportIssuanceAuthority");
    private final By issuancespinnerBy= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(10) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By UScitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[1]/span/div/div/div/div/label[2]/span[1]");
    private final By taxResidentBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[2]/span/div/div/div/div/label[2]/span[1]");
    private final By othertaxresidentBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[3]/span/div/div/div/div/label[2]/span[1]");
    private final By dualcitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[13]/span/div/div/div/div/label[2]/span[1]");
    private final By passportissue = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[11]/span/div/div/div/div/input");
    private final By nextButton = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[2]/div/button[3]");

    public AddNewBeneficialOwner(WebDriver driver) {
        this.driver = driver;
        Wait.waitForSpinner(driver, loadingmaskBy);
       Wait.waitForPageToLoad(driver, nameBy);
    }
    public void enterResidence(){
        driver.findElement(countryofresidence).click();
        driver.findElement(inputcountryofresidence).sendKeys("Oman" + Keys.ENTER);
    }
    public void uploadPassport(){
        driver.findElement(inputpassport).sendKeys("C:\\Users\\Rehmat.Nalban\\Desktop\\automated-test-framework (1)\\automated-test-framework\\coral-automation-test\\src\\test\\resources\\documents\\AGP-Rashid-PASSPORT-PAGE-1.pdf");
        Wait.waitForSpinner(driver, passportspinner);
    }
    public void enterMobNo(){
        driver.findElement(inputmobile).sendKeys("+971501234567");
    }
    public void enterEmail(){
        driver.findElement(inputemail).sendKeys("t.murad@gmail.com");
    }

    public void birthplace(String birthplace){
        Wait.waitForSpinner(driver, birthplacespinner);
        driver.findElement(birthplaceBy).click();
        driver.findElement(inputBirthplace).sendKeys(birthplace + Keys.ENTER);
    }

    public void issuanceauthority(String authissue){
        Wait.waitForSpinner(driver, issuancespinnerBy);
        driver.findElement(issuanceauthority).click();
        driver.findElement(inputissuanceBy).sendKeys(authissue + Keys.ENTER);
    }

    public void passportIssuedate(String dateissue){
        driver.findElement(passportissue).sendKeys(dateissue + Keys.ENTER);

    }
    public void setDualCitizenship(){ driver.findElement(dualcitizenBy).click();
    }
    public void selectOptions(){
        driver.findElement(UScitizenBy).click();
        driver.findElement(taxResidentBy).click();
        driver.findElement(othertaxresidentBy).click();

    }
    public OwnershipDetails submit(){
        driver.findElement(nextButton).click();
        Wait.waitForSpinner(driver, nextButton);
        return new OwnershipDetails(driver);
    }


}

