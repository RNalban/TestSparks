package ae.zand.devops.onboarding;
import ae.zand.devops.Setup;
import ae.zand.devops.constants.Paths;
import ae.zand.devops.views.common.Login;
import ae.zand.devops.views.corporate.OnBoardingPage;
import ae.zand.devops.views.onboarding.*;
import org.testng.annotations.Test;
public class CustomerJourneyTest extends Setup {
    @Test
    public void startJourney() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickonStartButton();
        customerJourney.uploadingTradeLicense("C:\\Users\\Rehmat.Nalban\\Desktop\\Documents Customer\\AGP TL 2022.pdf");
        customerJourney.uploadingMOA("C:\\Users\\Rehmat.Nalban\\Desktop\\Documents Customer\\AGP MOA 5th 121216.pdf");
        customerJourney.SelectOptions();
        customerJourney.submit();

    }

    @Test
    public void updateCompanyInformation() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickonStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        companyFillInformation.enterIncorporationDate("28-May-2012");
        companyFillInformation.placeofIncorporation("Dubai");
        //companyFillInformation.countryincorporation("United Arab Emirates");
        companyFillInformation.emiratesIncorporation("Dubai");
        companyFillInformation.formationType("Mainland");
        companyFillInformation.licenseType("Dubai Department Of Economic Development");
        companyFillInformation.entityType("Limited Liability Company");
        companyFillInformation.companyContactNumber("+97145438499");
        companyFillInformation.registeredCountry("United Arab Emirates");
        companyFillInformation.registeredEmirates("Dubai");
        companyFillInformation.registeredCity("Dubai");
        companyFillInformation.setRegisteredaddressBy("Bur Dubai");
        companyFillInformation.setRegisteredPOBOX("29011");
        companyFillInformation.supportingDocuments("C:\\Users\\Rehmat.Nalban\\Desktop\\automated-test-framework (1)\\automated-test-framework\\coral-automation-test\\src\\test\\resources\\documents\\ALWAHDANIABADARPassportOman.jpg");
        companyFillInformation.contactName("R Nalban");
        companyFillInformation.contactmobile("+971501234567");
        companyFillInformation.contactEmail("nalban786@gmail.com");
        companyFillInformation.setDesignation("Manager");
        companyFillInformation.contactbirthdate();
        companyFillInformation.setCountryresidence();
        companyFillInformation.setNationalityBy();
        companyFillInformation.setDualCitizen();

        companyFillInformation.submit();
    }

    @Test
    public void updateTaxInformation() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickonStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        taxInformation.setSelectUSregistered();
        taxInformation.setTaxRegisteration();
        taxInformation.setFFIBy();
        taxInformation.FFIReason();
        taxInformation.NFFEStatus();
        taxInformation.setSponsername();
        taxInformation.setSponsornumber();
        taxInformation.setGGINBy();
        taxInformation.setSanctionBy();
        taxInformation.setSubsiadiarysanctionBy();
        taxInformation.setTradesanctionBy();
        taxInformation.setExportgoodBy();
        taxInformation.setRemitmoneytosancBy();
        taxInformation.setAuditedsancBy();
        taxInformation.updateform();
        taxInformation.submit();
    }

    @Test
    public void updateOwnershipDetailsByAddingSignatory() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickonStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        OwnershipDetails ownershipDetails = taxInformation.submit();
        //ownershipDetails.addSignatoryfromExistingShareholder();
        AddNewSignatory addNewSignatory = ownershipDetails.addsignatoryuser();
        addNewSignatory.EntermobNumber();
        addNewSignatory.addEmail("abcd@gmail.com");
        addNewSignatory.birthplace("United Arab Emirates");
        addNewSignatory.addDesignation("Manager");
        addNewSignatory.setDualCitizenBy();
        addNewSignatory.otherDetails();
        addNewSignatory.setuploadEmiratesBy();
        addNewSignatory.setNationality("Oman");
        addNewSignatory.submit();

        driver.get(Paths.LOGOUT);
    }

    @Test
    public void updateOwnershipDetailsByAddingBeneficial() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickonStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        OwnershipDetails ownershipDetails = taxInformation.submit();
        ownershipDetails.addBeneficialFromExistingShareholder();
        AddNewBeneficialOwner addNewBeneficialOwner = ownershipDetails.addbeneficialuser();
        addNewBeneficialOwner.enterResidence();
        addNewBeneficialOwner.uploadPassport();
        addNewBeneficialOwner.enterMobNo();
        addNewBeneficialOwner.enterEmail();
        addNewBeneficialOwner.birthplace("United Arab Emirates");
        addNewBeneficialOwner.issuanceauthority("United Arab Emirates");
        addNewBeneficialOwner.passportIssuedate("05-Oct-2020");
        addNewBeneficialOwner.setDualCitizenship();
        addNewBeneficialOwner.selectOptions();
        addNewBeneficialOwner.submit();
    }

    @Test
    public void updateOwnershipDetailsByAddingBoardMembers() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickonStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        OwnershipDetails ownershipDetails = taxInformation.submit();
        ownershipDetails.addBoardMembers();
        AddBoardMember addBoardMember = ownershipDetails.addnewboardmember();
        addBoardMember.countryofresidence();
        addBoardMember.uploadPassport();
        addBoardMember.enterMobile("+971501234567");
        addBoardMember.enterEmail("abcd@gmail.com");
        addBoardMember.setBirthplace("United Arab Emirates");
        addBoardMember.setNationality("Oman");
        addBoardMember.enterAuthissue();
        addBoardMember.enterIssuedate();
        addBoardMember.setDualcitizenBy();
        addBoardMember.selectOptions();
        addBoardMember.submit();
    }

    @Test
    public void updateCustomerVerify() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickonStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        OwnershipDetails ownershipDetails = taxInformation.submit();
        CustomerVerify customerVerify = ownershipDetails.nextpage();
        customerVerify.checkConditions();
        customerVerify.submit();
    }
}

