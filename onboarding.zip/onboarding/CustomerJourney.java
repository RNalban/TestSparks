package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CustomerJourney {
    protected final WebDriver driver;
    private final By startButtonBy = By.xpath("//*[@id=\"startOnboarding\"]");
    private final By uploadingLicense = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div/div[1]/div/div/div[1]/div/span/div/div/div/div/div/div/div/input");
    private final By tradelicenseMaskBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation.removeSidebar._app-onboarding-layout.reduce-background > div.main-container > div:nth-child(2) > section > div > span > form > div > div:nth-child(1) > div > div > div:nth-child(1) > div > span > div > div > div > div > div > div.el-loading-mask");
    private final By moaMaskBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation.removeSidebar._app-onboarding-layout.reduce-background > div.main-container > div:nth-child(2) > section > div > span > form > div > div:nth-child(1) > div > div > div:nth-child(2) > div > span > div > div > div > div > div > div.el-loading-mask");
    private final By uploadingMOA = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div/div[1]/div/div/div[2]/div/span/div/div/div/div/div/div/div/input");
    private final By clickOnCompany = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div/div[2]/div/div[3]/table/tbody/tr[1]/td[3]/div/label/label[2]/span[1]/span");
    private final By clickIndividualOption1 = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div/div[2]/div/div[3]/table/tbody/tr[2]/td[3]/div/label/label[1]/span[1]/span");
    private final By clickIndividualOption2 = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div/div[2]/div/div[3]/table/tbody/tr[3]/td[3]/div/label/label[1]/span[1]/span");
    private final By clickOnNext = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div/div[3]/button");
    private final By removeDoc = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div/div[1]/div/div/div[1]/div/span/div/div/div/div/div/div[1]/button");
    private final By removeMOADoc = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/form/div/div[1]/div/div/div[2]/div/span/div/div/div/div/div/div[1]/button");
    private final By nextloading = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation.removeSidebar._app-onboarding-layout.reduce-background > div.main-container > div:nth-child(2) > section > div > span > form > div > div.u-display-flex.u-justify-content-flex-end.u-mt-3 > button > i"); //"//i[@class='el-icon-loading']"
    private final By nextbutton = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation.removeSidebar._app-onboarding-layout.reduce-background > div.main-container > div:nth-child(2) > section > div > span > form > div > div.u-display-flex.u-justify-content-flex-end.u-mt-3 > button");
    private final By nextmaskby = By.cssSelector("div > span > form > div > div.u-display-flex.u-justify-content-flex-end.u-mt-3 > button > i");

    public CustomerJourney(WebDriver driver) {
        this.driver = driver;
        Wait.waitForPageToLoad(driver, startButtonBy);
    }
    public void clickonStartButton(){
        driver.findElement(startButtonBy).click();
    }
    public void uploadingTradeLicense(String path){
        Wait.waitForPageToLoad(driver, removeDoc);
        driver.findElement(removeDoc).click();
        Wait.waitForPageToLoad(driver, uploadingLicense);
        driver.findElement(uploadingLicense).sendKeys(path);
        Wait.waitForSpinner(driver, tradelicenseMaskBy);

    }
    public void uploadingMOA(String path){
        //Wait.waitForPageToLoad(driver, removeMOADoc);
        driver.findElement(removeMOADoc).click();
        Wait.waitForPageToLoad(driver, uploadingMOA);
        driver.findElement(uploadingMOA).sendKeys(path);
        Wait.waitForSpinner(driver, moaMaskBy);
    }
    public void SelectOptions(){
        driver.findElement(clickOnCompany).click();
        driver.findElement(clickIndividualOption1).click();
        driver.findElement(clickIndividualOption2).click();
    }

    public CompanyFillInformation submit(){
        Wait.waitForPageToLoad(driver, clickOnNext);
        driver.findElement(clickOnNext).click();
        Wait.waitForSpinner(driver, nextloading);
        return new CompanyFillInformation(driver);
    }

    public CompanyFillInformation fastforward(){
       Wait.waitForPageToLoad(driver, removeMOADoc);
        Wait.waitForPageToLoad(driver, nextbutton);
        driver.findElement(nextbutton).click();
        Wait.waitForSpinner(driver, nextmaskby);
        return new CompanyFillInformation(driver);
    }



}