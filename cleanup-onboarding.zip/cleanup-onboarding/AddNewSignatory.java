package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AddNewSignatory {
    protected final WebDriver driver;

    private final By loadMaskBy = By.cssSelector("div.el-loading-mask");
    private final By nameBy = By.cssSelector("#signatories\\[1\\]\\.name");
    private final By emailBy = By.cssSelector("#signatories\\[1\\]\\.emailAddress");
    private final By mobileNumber = By.cssSelector("#signatories\\[1\\]\\.mobileNumber");

    private final By genderBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[2]/span/div/div/div/div/label[2]/span[1]/span");

    private final By designationBy = By.cssSelector("#signatories\\[1\\]\\.designation");

    private final By inputBirthplace = By.cssSelector("#signatories\\[1\\]\\.placeOfBirth");
    private final By birthplaceBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags");

    private final By option1By = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[1]/span/div/div/div/div/label[2]/span[1]");
    private final By option2By = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[2]/span/div/div/div/div/label[2]/span[1]");
    private final By option3By = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[3]/span/div/div/div/div/label[2]/span[1]");

      private final By nationalityBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(7) > span > div > div > div > div > div.multiselect__tags");
    private final By inputNationality = By.cssSelector("#signatories\\[1\\]\\.mainNationality\\.nationality");

    private final By birthPlaceSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");

    private final By inputEmiratesFrontBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div:nth-child(2) > span > div > div > div > div > div > div > div > input");
    private final By inputEmiratesBackBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div:nth-child(3) > span > div > div > div > div > div > div > div > input");
    private final By emiratesFrontSpinner = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[2]/div[2]/span/div/div/div/div/div/div[3]");
    private final By emiratesBackSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div:nth-child(3) > span > div > div > div > div > div > div.el-loading-mask");

    private final By dualCitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[12]/span/div/div/div/div/label[2]/span[1]");

    private final By nextButton = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div._onboarding-footer.u-mb-3.u-pr-4 > div > button.el-button.el-button--primary._button");

        public AddNewSignatory(WebDriver driver) {
        this.driver=driver;

        Wait.waitForPageToLoad(driver, nameBy);
    }
    public void setUploadEmiratesBy(){

        driver.findElement(inputEmiratesFrontBy).sendKeys(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/MRBADAR ID.jpg");
        Wait.waitForSpinner(driver, emiratesFrontSpinner);
        driver.findElement(inputEmiratesBackBy).sendKeys(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/MRBADAR ID.jpg");
        Wait.waitForSpinner(driver, emiratesBackSpinner);
    }


    public void selectGender(){
        driver.findElement(genderBy).click();
    }

    public void enterMobNumber(){
        driver.findElement(mobileNumber).sendKeys("+971501234567" + Keys.ENTER);
    }
    public void addEmail(String email){
        driver.findElement(emailBy).sendKeys(email + Keys.ENTER);
    }

    public void birthplace(String birthplace){
        Wait.waitForSpinner(driver, birthPlaceSpinner);
        driver.findElement(birthplaceBy).click();
        driver.findElement(inputBirthplace).sendKeys(birthplace + Keys.ENTER);


    }
    public void addDesignation(String designation){
        driver.findElement(designationBy).sendKeys(designation + Keys.ENTER);
    }


    public void setNationality(String nationality){
        Wait.waitForSpinner(driver, emiratesBackSpinner);
        driver.findElement(nationalityBy).click();
        driver.findElement(inputNationality).sendKeys(nationality + Keys.ENTER);
    }
    public void setDualCitizenBy(){
        driver.findElement(dualCitizenBy).click();
    }

    public void otherDetails(){
        driver.findElement(option1By).click();
        driver.findElement(option2By).click();
        driver.findElement(option3By).click();
    }

    public OwnershipDetails submit(){

        driver.findElement(nextButton).click();
        Wait.waitForSpinner(driver, nextButton);
        return new OwnershipDetails(driver);
    }

}
