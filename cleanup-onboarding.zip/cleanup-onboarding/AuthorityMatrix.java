package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AuthorityMatrix {
    protected final WebDriver driver;

    private final By newRuleBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._header.u-mb-4 > div:nth-child(2) > button");
    private final By tableLoadMaskBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._authority-matrix > section > div.el-loading-mask");

    private final By productBy = By.xpath("//*[@id=\"authorityMatrix.drawer.productCategory\"]/div/div/div[2]");
    private final By inputProductBy = By.cssSelector("#authorityMatrix\\.drawer\\.productCategory > div > div > div.multiselect__tags > input");

    private final By conditionBy = By.xpath("//*[@id=\"authorityMatrix.drawer.amount\"]/div/div/div[2]");
    private final By inputconditionBy = By.cssSelector("#authorityMatrix\\.drawer\\.amount > div > div > div.multiselect__tags > input");

    private final By inputAmountBy = By.cssSelector("#authorityMatrix\\.drawer\\.amount2 > div > div._has--prepend.mb-2.el-input.el-input-group.el-input-group--append._input.is--light.show-currency > input");

    private final By authoriserBy = By.cssSelector("#authorityMatrix\\.drawer\\.authorizedBy0 > div > div > div.el-cascader__tags > input");
    private final By authoriserDropdownBy = By.cssSelector(".el-cascader-node > label > span > span");

    private final By previewBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._authority-matrix > div > div > div > section > div._app-drawer__footer.u-py-3.u-px-4 > button.el-button.el-button--primary._button");
    private final By productPreviewBy = By.cssSelector("#app-scrollbar-drawer > div.os-padding > div > div > div > div > div > div:nth-child(1) > div.el-col.el-col-16 > div.mt-2.u-display-flex.u-align-items-center");

    private final By saveButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._authority-matrix > div > div > div > section > div._app-drawer__footer.u-py-3.u-px-4 > button.el-button.el-button--primary._button");

    private final By checkConditionBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/section/div[3]/div/div/label/span[1]");

    private final By finishBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._onboarding-footer > div > div > button");
    private final By finishSpinnerBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._onboarding-footer > div > div > button >i");

    public AuthorityMatrix(WebDriver driver) {
        this.driver = driver;
        Wait.waitForPageToLoad(driver, newRuleBy);
        Wait.waitForSpinner(driver, tableLoadMaskBy);
    }
    public void addingNewRule(){
        driver.findElement( newRuleBy).click();
        Wait.waitForDrawer(driver, productBy);
        driver.findElement(productBy).click();
        driver.findElement(inputProductBy).sendKeys("All" + Keys.ENTER);
        driver.findElement(conditionBy).click();
        driver.findElement(inputconditionBy).sendKeys("Less than or equal" + Keys.ENTER);
        driver.findElement(inputAmountBy).clear();
        driver.findElement(inputAmountBy).sendKeys("9999999999");
        Wait.waitForDrawer(driver, authoriserBy);
        driver.findElement(authoriserBy).click();
        Wait.waitForDrawer(driver, authoriserDropdownBy);
        driver.findElement(authoriserDropdownBy).click();
        driver.findElement(previewBy).click();
        Wait.waitForPageToLoad(driver, productPreviewBy);
        driver.findElement(saveButtonBy).click();
    }

    public void setCheckConditionBy(){
        Wait.waitForSpinner(driver, tableLoadMaskBy);
        driver.findElement(checkConditionBy).click();
    }
    public void Finish(){
        driver.findElement(finishBy).click();
        Wait.waitForSpinner(driver, finishSpinnerBy);
    }
}
