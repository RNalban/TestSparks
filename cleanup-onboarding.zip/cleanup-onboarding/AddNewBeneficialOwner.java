package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AddNewBeneficialOwner {
    protected final WebDriver driver;

    private final By loadingMaskBy = By.cssSelector("div.el-loading-mask");
    private final By nameBy = By.xpath("//*[@id=\"beneficialOwners[1].name\"]");

    private final By inputMobile = By.cssSelector("#beneficialOwners\\[1\\]\\.mobileNumber");
    private final By inputEmail = By.cssSelector("#beneficialOwners\\[1\\]\\.emailAddress");

    private final By inputBirthplace = By.cssSelector("#beneficialOwners\\[1\\]\\.placeOfBirth");
    private final By birthPlaceSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");
    private final By birthplaceBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags");

    private final By countryOfResidence = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(8) > span > div > div > div > div > div.multiselect__tags");
    private final By inputCountryOfResidence = By.xpath("//*[@id=\"beneficialOwners[1].countryOfResidence\"]");

    private final By inputPassport = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div > span > div > div > div > div > div > div > div > input");
    private final By passportSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div > span > div > div > div > div > div > div.el-loading-mask > div");

    private final By issuanceAuthority = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(10) > span > div > div > div > div > div.multiselect__tags");
    private final By inputIssuanceBy = By.cssSelector("#beneficialOwners\\[1\\]\\.mainNationality\\.passportIssuanceAuthority");
    private final By issuanceSpinnerBy= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(10) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");

    private final By dualCitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[13]/span/div/div/div/div/label[2]/span[1]");

    private final By USCitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[1]/span/div/div/div/div/label[2]/span[1]");
    private final By taxResidentBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[2]/span/div/div/div/div/label[2]/span[1]");
    private final By otherTaxResidentBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[3]/span/div/div/div/div/label[2]/span[1]");

    private final By passportIssueDateBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[11]/span/div/div/div/div/input");

    private final By nextButton = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[2]/div/button[3]");

    public AddNewBeneficialOwner(WebDriver driver) {
        this.driver = driver;
        Wait.waitForSpinner(driver, loadingMaskBy);
       Wait.waitForPageToLoad(driver, nameBy);
    }
    public void enterResidence(){
        driver.findElement(countryOfResidence).click();
        driver.findElement(inputCountryOfResidence).sendKeys("Oman" + Keys.ENTER);
    }
    public void uploadPassport(String passport){
        driver.findElement(inputPassport).sendKeys(passport);
        Wait.waitForSpinner(driver, passportSpinner);
    }
    public void enterMobNo(String mobileNumber){
        driver.findElement(inputMobile).sendKeys(mobileNumber + Keys.ENTER);
    }

    public void enterEmail(String email){
        driver.findElement(inputEmail).sendKeys(email + Keys.ENTER);
    }

    public void birthplace(String birthplace){
        Wait.waitForSpinner(driver, birthPlaceSpinner);
        driver.findElement(birthplaceBy).click();
        driver.findElement(inputBirthplace).sendKeys(birthplace + Keys.ENTER);
    }

    public void setIssuanceAuthority(String authIssue){
        Wait.waitForSpinner(driver, issuanceSpinnerBy);
        driver.findElement(issuanceAuthority).click();
        driver.findElement(inputIssuanceBy).sendKeys(authIssue + Keys.ENTER);
    }

    public void passportIssueDate(String dateIssue){
        driver.findElement(passportIssueDateBy).sendKeys(dateIssue + Keys.ENTER);

    }
    public void setDualCitizenship(){ driver.findElement(dualCitizenBy).click();
    }
    public void selectOptions(){
        driver.findElement(USCitizenBy).click();
        driver.findElement(taxResidentBy).click();
        driver.findElement(otherTaxResidentBy).click();

    }
    public OwnershipDetails submit(){
        driver.findElement(nextButton).click();
        Wait.waitForSpinner(driver, nextButton);
        return new OwnershipDetails(driver);
    }


}

