package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UserSetupandRole {
    protected final WebDriver driver;

    private final By spinnerBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/section/div[2]/section/div/div[7]");

    private final By quickAddBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/section/div[1]/div[2]/div/div/div[2]");
    private final By quickDropdownBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._header.mb-4 > div:nth-child(2) > div > div > div.multiselect__content-wrapper > ul > li:nth-child(1) > span");

    private final By newUserBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._header.mb-4 > div:nth-child(2) > div > button");

    private final By nextButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._onboarding-footer > div > div > button");
    private final By nextspinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._onboarding-footer > div > div > button > i");

    private final By tableloadingmaskBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > section > div._user-management > section > div > div.el-loading-mask");
    public UserSetupandRole(WebDriver driver) {
        this.driver=driver;
        Wait.waitForPageToLoad(driver, quickAddBy);
    }
    public QuickAddUser quickAddAuthoriser(){
        driver.findElement(quickAddBy).click();
        Wait.waitForDrawer(driver, quickDropdownBy);
        driver.findElement(quickDropdownBy).click();
        return new QuickAddUser(driver);
    }

    public AddNewUser setAddNewUser(){
        Wait.waitForPageToLoad(driver, newUserBy);
        driver.findElement(newUserBy).click();
        Wait.waitForSpinner(driver, newUserBy);
        return new AddNewUser(driver);
    }
    public AuthorityMatrix submit(){

        Wait.waitForSpinner(driver, tableloadingmaskBy);
        driver.findElement(nextButtonBy).click();
        Wait.waitForSpinner(driver, nextspinner);
        return new AuthorityMatrix(driver);
    }

}
