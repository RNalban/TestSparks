package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class PreviewPage {
    private final WebDriver driver;
    private final By nextButtonBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/div[3]/button[3]");

    private final By userIconBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/div[2]/div/div[1]/span");
    private final By allOptions = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/div[2]/div[2]/div/div/div[1]/span/label/label/span/span");

    private final By addGroupNameBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-my-4 > span > button");
    private final By inputGroupBy = By.cssSelector("input.el-input__inner");

    private final By confirmGroupBy = By.cssSelector(" button.el-button.el-button--primary.el-button--small._button");
    private final By createUserBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/div[3]/button[3]");

    private final By saveButtonBy = By.cssSelector("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/div[3]/button[3]");

    public PreviewPage(WebDriver driver) {
        this.driver= driver;
        Wait.waitForPageToLoad(driver,nextButtonBy);
    }
    public void clickOnNext(){
        driver.findElement(nextButtonBy).click();

    }
    public void setAllOptions(){
        driver.findElement(allOptions).click();
    }
    public void setAddGroupNameBy(String groupName){
        driver.findElement(addGroupNameBy).click();
        Wait.waitForDrawer(driver, inputGroupBy);
        driver.findElement(inputGroupBy).sendKeys(groupName + Keys.ENTER);
        driver.findElement(confirmGroupBy).click();

    }
    public void createUser(){
        Wait.waitForPageToLoad(driver, createUserBy);
        driver.findElement(createUserBy).click();
        Wait.waitForSpinner(driver, createUserBy);
    }

}
