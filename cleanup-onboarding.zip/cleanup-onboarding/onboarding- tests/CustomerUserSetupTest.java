package ae.zand.devops.onboarding;

import ae.zand.devops.Setup;
import ae.zand.devops.views.common.Login;
import ae.zand.devops.views.corporate.CustomerUserSetup;
import ae.zand.devops.views.onboarding.*;
import org.testcontainers.shaded.org.apache.commons.lang.RandomStringUtils;
import org.testng.annotations.Test;

public class CustomerUserSetupTest extends Setup {

    @Test
    public void startUserSetup(){
        Login login = new Login(driver);
        CustomerUserSetup customerUserSetup = login.loginCustomerUserSetup(CUSTOMER_USERNAME,CUSTOMER_PASSWORD);
        customerUserSetup.goTostartsetup();
    }

    @Test (dependsOnMethods = {"startUserSetup"})
    public void quickAddAuthoriser(){
        UserSetupandRole userSetupandRole = new UserSetupandRole(driver);
        QuickAddUser quickAddUser= userSetupandRole.quickAddAuthoriser();
        quickAddUser.setAuthoriserType();
        quickAddUser.setAdminAccess();
        quickAddUser.setDailyApproval();
        quickAddUser.setDailyDrawDown();
        quickAddUser.setTransactionLimit();
        quickAddUser.setPreviewAndNextButtonBy();
        quickAddUser.createUser();
    }

    @Test (dependsOnMethods = {"startUserSetup"})
    public void addingInputterUser(){
        UserSetupandRole userSetupandRole = new UserSetupandRole(driver);
        AddNewUser addNewUser = userSetupandRole.setAddNewUser();
        addNewUser.enterEmailAddress("nalban786@gmail.com");
        addNewUser.enterUserType("Inputter");
        addNewUser.uploadEmiratesIDBy(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/KhoulaID.jpg");
        addNewUser.setMobNumberBy("+971564506145");
        addNewUser.setGenderBy();
        addNewUser.setTransactionLimitBy("999999999");
        addNewUser.setNationalBy("United Arab Emirates");
        PreviewPage previewPage= addNewUser.setPreviewButtonBy();
        previewPage.clickOnNext();
        previewPage.setAllOptions();
        previewPage.setAddGroupNameBy(RandomStringUtils.randomAlphabetic(7));
        previewPage.createUser();

    }

    @Test (dependsOnMethods = {"startUserSetup"})
    public void addingAdminUser(){
        UserSetupandRole userSetupandRole = new UserSetupandRole(driver);
        AddNewUser addNewUser = userSetupandRole.setAddNewUser();
        addNewUser.enterEmailAddress("r.murad@gmail.com");
        addNewUser.enterUserType("Admin");
        addNewUser.uploadEmiratesIDBy(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/AGP RASHID Murad EID 2020 1.jpg");
        addNewUser.setMobNumberBy("+971561234567");
        addNewUser.setMaleGenderBy();
        addNewUser.setNationalBy("United Arab Emirates");
        SaveForm saveForm = addNewUser.adminPreviewAndSave();
        saveForm.clickOnSave();
    }

    @Test (dependsOnMethods = {"startUserSetup"})
    public void AddNewRule(){
        UserSetupandRole userSetupandRole = new UserSetupandRole(driver);
        AuthorityMatrix authorityMatrix = userSetupandRole.submit();
        authorityMatrix.addingNewRule();
        authorityMatrix.setCheckConditionBy();
        authorityMatrix.Finish();


    }

}

