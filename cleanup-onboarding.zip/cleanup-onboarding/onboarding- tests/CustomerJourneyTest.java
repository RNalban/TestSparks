package ae.zand.devops.onboarding;
import ae.zand.devops.Setup;
import ae.zand.devops.constants.Paths;
import ae.zand.devops.views.common.Login;
import ae.zand.devops.views.corporate.OnBoardingPage;
import ae.zand.devops.views.onboarding.*;
import org.testng.annotations.Test;
public class CustomerJourneyTest extends Setup {
    @Test
    public void startJourney() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickOnStartButton();
        customerJourney.uploadingTradeLicense(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/AGP TL 2022.pdf");
        customerJourney.uploadingMOA(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/AGP MOA 5th 121216.pdf");
        customerJourney.SelectOptions();
        customerJourney.submit();

    }

    @Test
    public void updateCompanyInformation() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickOnStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        companyFillInformation.enterIncorporationDate("28-May-2012");
        companyFillInformation.placeofIncorporation("Dubai");
        companyFillInformation.countryincorporation("United Arab Emirates");
        companyFillInformation.emiratesIncorporation("Dubai");
        companyFillInformation.formationType("Mainland");
        companyFillInformation.licenseType("Dubai Department Of Economic Development");
        companyFillInformation.entityType("Limited Liability Company");
        companyFillInformation.companyContactNumber("+97145438499");
        companyFillInformation.registeredCountry("United Arab Emirates");
        companyFillInformation.registeredEmirates("Dubai");
        companyFillInformation.registeredCity("Dubai");
        companyFillInformation.setRegisteredaddressBy("Bur Dubai");
        companyFillInformation.setRegisteredPOBOX("29011");
        companyFillInformation.supportingDocuments(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/ALWAHDANIABADARPassportOman.jpg");
        companyFillInformation.contactName("R Nalban");
        companyFillInformation.contactmobile("+971501234567");
        companyFillInformation.contactEmail("nalban786@gmail.com");
        companyFillInformation.setDesignation("Manager");
        companyFillInformation.contactbirthdate();
        companyFillInformation.setCountryresidence();
        companyFillInformation.setNationalityBy();
        companyFillInformation.setDualCitizen();

        companyFillInformation.submit();
    }

    @Test
    public void updateTaxInformation() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickOnStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        taxInformation.setSelectUSregistered();
        taxInformation.setTaxRegisteration();
        taxInformation.setFFIBy();
        taxInformation.FFIReason();
        taxInformation.NFFEStatus();
        taxInformation.setSponsername();
        taxInformation.setSponsornumber();
        taxInformation.setGGINBy();
        taxInformation.setSanctionBy();
        taxInformation.setSubsiadiarysanctionBy();
        taxInformation.setTradesanctionBy();
        taxInformation.setExportgoodBy();
        taxInformation.setRemitmoneytosancBy();
        taxInformation.setAuditedsancBy();
        taxInformation.updateform();
        taxInformation.submit();
    }

    @Test
    public void updateOwnershipDetailsByAddingSignatory() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickOnStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        OwnershipDetails ownershipDetails = taxInformation.submit();

        AddNewSignatory addNewSignatory = ownershipDetails.addSignatoryUser();
        addNewSignatory.enterMobNumber();
        addNewSignatory.addEmail("abcd@gmail.com");
        addNewSignatory.birthplace("United Arab Emirates");
        addNewSignatory.addDesignation("Manager");
        addNewSignatory.setDualCitizenBy();
        addNewSignatory.otherDetails();
        addNewSignatory.setUploadEmiratesBy();
        addNewSignatory.setNationality("Oman");
        addNewSignatory.submit();
        driver.get(Paths.LOGOUT);
    }

    @Test
    public void updateOwnershipDetailsByAddingBeneficial() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickOnStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        OwnershipDetails ownershipDetails = taxInformation.submit();
        ownershipDetails.addBeneficialFromExistingShareholder();
        AddNewBeneficialOwner addNewBeneficialOwner = ownershipDetails.addBeneficialUser();
        addNewBeneficialOwner.enterResidence();
        addNewBeneficialOwner.uploadPassport(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/AGP-Rashid-PASSPORT-PAGE-1.pdf");
        addNewBeneficialOwner.enterMobNo("+971501234567");
        addNewBeneficialOwner.enterEmail("t.murad@gmail.com");
        addNewBeneficialOwner.birthplace("United Arab Emirates");
        addNewBeneficialOwner.setIssuanceAuthority("United Arab Emirates");
        addNewBeneficialOwner.passportIssueDate("05-Oct-2020");
        addNewBeneficialOwner.setDualCitizenship();
        addNewBeneficialOwner.selectOptions();
        addNewBeneficialOwner.submit();

    }

    @Test
    public void updateOwnershipDetailsByAddingBoardMembers() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickOnStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        OwnershipDetails ownershipDetails = taxInformation.submit();
        ownershipDetails.addBoardMembers();
        AddBoardMember addBoardMember = ownershipDetails.addNewBoardMember();
        addBoardMember.countryOfResidence();
        addBoardMember.uploadPassport(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/ALWAHDANIABADARPassportOman.jpg");
        addBoardMember.enterMobile("+971501234567");
        addBoardMember.enterEmail("abcd@gmail.com");
        addBoardMember.setBirthplace("United Arab Emirates");
        addBoardMember.setNationality("Oman");
        addBoardMember.enterAuthIssue();
        addBoardMember.enterIssueDate();
        addBoardMember.setDualCitizenBy();
        addBoardMember.selectOptions();
        addBoardMember.submit();
    }

    @Test
    public void updateCustomerVerify() {
        Login login = new Login(driver);
        OnBoardingPage onBoardingPage = login.loginCustomerUser(CUSTOMER_USERNAME, CUSTOMER_PASSWORD);
        CustomerJourney customerJourney = onBoardingPage.goToOnBoarding();
        customerJourney.clickOnStartButton();
        CompanyFillInformation companyFillInformation = customerJourney.fastforward();
        TaxInformation taxInformation = companyFillInformation.submit();
        OwnershipDetails ownershipDetails = taxInformation.submit();
        CustomerVerify customerVerify = ownershipDetails.nextPage();
        customerVerify.checkConditions();
        customerVerify.submit();
    }
}

