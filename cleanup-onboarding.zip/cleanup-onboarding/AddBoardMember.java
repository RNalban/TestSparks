package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.checkerframework.checker.units.qual.K;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import java.security.Key;

public class AddBoardMember {
    protected final WebDriver driver;

    private final By loadingmaskBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div.el-loading-mask");
    private final By nameBy = By.cssSelector("#boardMembers\\[1\\]\\.name");

    private final By mobileNumberBy = By.cssSelector("#boardMembers\\[1\\]\\.mobileNumber");
    private final By emailAddressBy = By.cssSelector("#boardMembers\\[1\\]\\.emailAddress");

    private final By birthplaceBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(5) > span > div > div > div > div > div.multiselect__tags");
    private final By inputBirthplace = By.cssSelector("#boardMembers\\[1\\]\\.placeOfBirth");

    private final By nationalityBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(7) > span > div > div > div > div > div.multiselect__tags");
    private final By inputNationality = By.cssSelector("#boardMembers\\[1\\]\\.mainNationality\\.nationality");

    private final By issueDateBy= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(11) > span > div > div > div > div > input");
    private final By authIssueBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(10) > span > div > div > div > div > div.multiselect__tags");
    private final By inputAuthIssueBy = By.cssSelector("#boardMembers\\[1\\]\\.mainNationality\\.passportIssuanceAuthority");

    private final By countryResidenceOption= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(8) > span > div > div > div > div > div.multiselect__tags");
    private final By inputResidence= By.cssSelector("#boardMembers\\[1\\]\\.countryOfResidence");
    private final By residenceSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(1) > div:nth-child(8) > span > div > div > div > div > div.multiselect__tags > div.multiselect__spinner");

    private final By inputPassportBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[2]/div/span/div/div/div/div/div/div/div/input");
    private final By passportSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div.u-p-4 > div:nth-child(1) > div:nth-child(2) > form > div > div:nth-child(2) > div > span > div > div > div > div > div > div.el-loading-mask > div");



    private final By dualcitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[1]/form/div/div[1]/div[13]/span/div/div/div/div/label[2]/span[1]");

    private final By UScitizenBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[1]/span/div/div/div/div/label[2]/span[1]");
    private final By taxResidentBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[2]/span/div/div/div/div/label[2]/span[1]");
    private final By othertaxresidentBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[1]/div[2]/form/div[3]/span/div/div/div/div/label[2]/span[1]");

    private final By nextButtonBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[2]/div/button[3]");
    public AddBoardMember(WebDriver driver) {
        this.driver = driver;

        Wait.waitForPageToLoad(driver, nameBy);
    }

    public void countryOfResidence(){
        driver.findElement(countryResidenceOption).click();
        driver.findElement(inputResidence).sendKeys("Oman" + Keys.ENTER);
    }

    public void uploadPassport(String passport){
        driver.findElement(inputPassportBy).sendKeys(passport);
        Wait.waitForSpinner(driver, passportSpinner);
    }

    public void enterMobile(String mobile){
        Wait.waitForSpinner(driver,passportSpinner);
        driver.findElement(mobileNumberBy).sendKeys(mobile + Keys.ENTER);
    }
    public void enterEmail(String email){
        driver.findElement(emailAddressBy).sendKeys(email + Keys.ENTER);
    }

    public void setBirthplace(String birthplace){
        driver.findElement(birthplaceBy).click();
        driver.findElement(inputBirthplace).sendKeys(birthplace + Keys.ENTER);

    }

    public void setNationality(String nationality){
        driver.findElement(nationalityBy).click();
        driver.findElement(inputNationality).sendKeys(nationality+ Keys.ENTER);
    }
    public void enterIssueDate(){
        driver.findElement(issueDateBy).sendKeys("13-Apr-2019"+Keys.ENTER);
    }
    public void enterAuthIssue(){
        driver.findElement(authIssueBy).click();
        driver.findElement(inputAuthIssueBy).sendKeys("United Arab Emirates" + Keys.ENTER);
    }
    public void setDualCitizenBy(){
        driver.findElement(dualcitizenBy).click();
    }
    public void selectOptions(){
        driver.findElement(UScitizenBy).click();
        driver.findElement(taxResidentBy).click();
        driver.findElement(othertaxresidentBy).click();
    }
    public OwnershipDetails submit(){
        driver.findElement(nextButtonBy).click();
        Wait.waitForSpinner(driver, nextButtonBy);
        return new OwnershipDetails(driver);
    }
}

