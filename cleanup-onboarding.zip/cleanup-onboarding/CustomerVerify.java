package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CustomerVerify {
    protected final WebDriver driver;

    private final By loadingmaskBy = By.cssSelector("div.el-loading-mask");
    private final By conditionBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div/form/div[2]/div[2]/div/div/label/span[1]");
    private final By submitButton = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div/form/div[2]/div[2]/div/button");

    public CustomerVerify(WebDriver driver) {
        this.driver = driver;
        Wait.waitForSpinner(driver, loadingmaskBy);
    }

    public void checkConditions(){
        driver.findElement(conditionBy).click();
    }

    public void submit(){
        driver.findElement(submitButton).click();

    }

}
