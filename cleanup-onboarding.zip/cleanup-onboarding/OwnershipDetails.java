package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OwnershipDetails {
    protected final WebDriver driver;

    private final By shareholderLoadingMaskBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > div > span > div:nth-child(1) > div.el-loading-mask");
    private final By signatoriesLoadingMaskBy = By.cssSelector("#signatories > div.el-loading-mask");
    private final By beneficialOwnersLoadingMaskBy = By.cssSelector("#beneficial-owners > div.el-loading-mask");
    private final By boardMembersLoadingMaskBy = By.cssSelector("#board-members > div.el-loading-mask");

    private final By optionsBy =  By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[1]/div[2]/div[4]/div[2]/table/tbody/tr[1]/td[5]/div/span/div[2]/button/i");
    private final By viewDetails = By.xpath("(//*[@id=\"SHAREHOLDER_2_viewEdit\"])[2]");

    private final By addSignatoryBy = By.cssSelector("#signatories > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > div > div > div.multiselect__tags");
    private final By getAddSignatoryBy =By.xpath("//*[@id=\"signatories\"]/div[1]/div/div/div/div[3]/ul/li[2]/span/label/span/span");
    private final By addNewSignatoryBy = By.cssSelector("#signatories > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > button");

    private final By addBeneficialBy  = By.cssSelector("#beneficial-owners > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > div > div > div.multiselect__tags");
    private final By getBeneficialBy = By.xpath("//*[@id=\"beneficial-owners\"]/div[1]/div/div/div/div[3]/ul/li[1]/span");
    private final By addNewBeneficiaryBy = By.cssSelector("#beneficial-owners > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > button");

    private final By addBoardMemberBy= By.cssSelector("#board-members > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > div > div > div.multiselect__tags");
    private final By getAddBoardMemberBy = By.cssSelector("#board-members > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > div > div > div.multiselect__content-wrapper > ul > li:nth-child(1) > span");
    private final By addNewBoardMemberBy = By.cssSelector("#board-members > div.u-display-flex.u-align-items-center.u-justify-content-space-between > div > button");

    private final By nextButtonBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/div/span/div[5]/div/button");

    public OwnershipDetails(WebDriver driver) {
        this.driver = driver;
        Wait.waitForSpinner(driver, shareholderLoadingMaskBy);
        Wait.waitForSpinner(driver, signatoriesLoadingMaskBy);
        Wait.waitForSpinner(driver, beneficialOwnersLoadingMaskBy);
        Wait.waitForSpinner(driver, boardMembersLoadingMaskBy );
        Wait.waitForPageToLoad(driver, optionsBy);
    }

    public void viewDetails(){
        driver.findElement(optionsBy).click();
        Wait.waitForDrawer(driver, viewDetails );
        driver.findElement(viewDetails).click();
    }

    public AddNewSignatory addSignatoryUser(){
        driver.findElement(addNewSignatoryBy).click();
        return new AddNewSignatory(driver);
    }

    public void addBeneficialFromExistingShareholder(){
        driver.findElement(addBeneficialBy).click();
        Wait.waitForDrawer(driver, getBeneficialBy);
        driver.findElement(getBeneficialBy).click();
    }

    public AddNewBeneficialOwner addBeneficialUser(){
        driver.findElement(addNewBeneficiaryBy).click();
        return new AddNewBeneficialOwner(driver);
    }

    public void addBoardMembers(){
        driver.findElement(addBoardMemberBy).click();
        Wait.waitForDrawer(driver, getAddBoardMemberBy);
        driver.findElement(getAddBoardMemberBy).click();
    }

    public AddBoardMember addNewBoardMember(){
        driver.findElement(addNewBoardMemberBy).click();
        return new AddBoardMember(driver);
    }

    public CustomerVerify nextPage(){
        driver.findElement(nextButtonBy).click();
        Wait.waitForSpinner(driver, nextButtonBy);
        return new CustomerVerify(driver);
    }
}
