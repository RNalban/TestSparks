package ae.zand.devops.views.onboarding;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AddNewUser {
    protected final WebDriver driver;
    private final By emailBy = By.cssSelector("input#email");

    private final By userTypeBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/form/div/div[1]/span[2]/div/div/div/div[1]/div[2]");
    private final By inputUserType = By.cssSelector("input#userType");

    private final By mobNumberBy = By.cssSelector("input#phoneNumber");

    private final By genderBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/form/div/div[1]/span[6]/div/div/div/div/label[2]/span[1]/span");
    private final By maleGenderBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(1) > span:nth-child(6) > div > div > div > div > label:nth-child(1) > span.el-radio__input > span");

    private final By inputEmiratesIDBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(2) > span:nth-child(4) > div > div > div > div > div > div > div > input");
    private final By emiratesSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(2) > span:nth-child(4) > div > div > div > div > div > div.el-loading-mask > div");
    private final By inputBackEmirateBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(2) > span:nth-child(5) > div > div > div > div > div > div > div > input");
    private final By emiratesBackSpinner = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(2) > span:nth-child(5) > div > div > div > div > div > div.el-loading-mask > div");

    private final By nationalBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > form > div > div:nth-child(1) > span:nth-child(5) > div > div > div > div.multiselect.is--light > div.multiselect__tags");
    private final By inputNationality = By.cssSelector("input#nationality");

    private final By transactionLimitBy = By.cssSelector("input#perTransactionLimit");

    private final By previewButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation._app-onboarding-layout.test > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-my-4 > button.el-button.u-ml-3.el-button--primary._button");

    private final By saveButtonBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/span/section/div[3]/button[3]");

    public AddNewUser(WebDriver driver) {
        this.driver=driver;
       Wait.waitForPageToLoad(driver, emailBy);
        Wait.waitForDrawer(driver, userTypeBy);
    }

    public void enterEmailAddress(String email){

        driver.findElement(emailBy).sendKeys(email + Keys.ENTER);
    }
    public void  enterUserType(String userType){

        driver.findElement(userTypeBy).click();
        driver.findElement(inputUserType).sendKeys(userType + Keys.ENTER);
    }

    public void setMobNumberBy(String mobNumber){
        Wait.waitForPageToLoad(driver, mobNumberBy);
        driver.findElement(mobNumberBy).clear();
        driver.findElement(mobNumberBy).sendKeys(mobNumber);}

    public void setNationalBy(String nationality){
        Wait.waitForSpinner(driver, emiratesBackSpinner);
        driver.findElement(nationalBy).click();
        driver.findElement(inputNationality).sendKeys(nationality + Keys.ENTER);
    }

    public void setGenderBy(){driver.findElement(genderBy).click();}

    public void uploadEmiratesIDBy(String path){
        Wait.waitForPageToLoad(driver, inputEmiratesIDBy);
        driver.findElement(inputEmiratesIDBy).sendKeys(path);
        Wait.waitForSpinner(driver, emiratesSpinner);
        driver.findElement(inputBackEmirateBy).sendKeys(path);
        Wait.waitForSpinner(driver, emiratesBackSpinner);
    }
    public void setTransactionLimitBy(String limit){
        driver.findElement(transactionLimitBy).clear();
        driver.findElement(transactionLimitBy).sendKeys(limit);
    }
    public PreviewPage setPreviewButtonBy(){

        driver.findElement(previewButtonBy).click();
        return new PreviewPage(driver);

    }

    public void setMaleGenderBy() {
        Wait.waitForSpinner(driver, emiratesBackSpinner);
        driver.findElement(maleGenderBy).click();
    }
    public SaveForm adminPreviewAndSave(){

        driver.findElement(previewButtonBy).click();
        return new SaveForm(driver);

    }

}





    

