package ae.zand.devops.views.UAM;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AuthorityMatrix {
    protected final WebDriver driver;
    private final By newRuleBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > section > div.o-heading__right.el-row > button");
    private final By searchUserBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > section > div.o-heading__right.el-row > div > input");
    private final By productBy = By.cssSelector("#authorityMatrix\\.drawer\\.productCategory > div > div > div.multiselect__tags");
    private final By inputProductBy = By.cssSelector("#authorityMatrix\\.drawer\\.productCategory > div > div > div.multiselect__tags > input");

    private final By conditionBy = By.cssSelector("#authorityMatrix\\.drawer\\.amount > div > div > div.multiselect__tags");
    private final By inputConditionBy = By.cssSelector("#authorityMatrix\\.drawer\\.amount > div > div > div.multiselect__tags > input");

    private final By inputAmountBy = By.cssSelector("#authorityMatrix\\.drawer\\.amount2 > div > div._has--prepend.mb-2.el-input.el-input-group.el-input-group--append._input.is--light.show-currency > input");

    private final By authoriserBy = By.cssSelector("#authorityMatrix\\.drawer\\.authorizedBy0 > div > div > div.el-cascader__tags > input");
    private final By authoriserDropdownBy = By.cssSelector(".el-cascader-node > label > span > span");

    private final By previewBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > div:nth-child(3) > div._authority-matrix > div > div > div > section > div._app-drawer__footer.u-py-3.u-px-4 > button.el-button.el-button--primary._button");
    private final By productPreviewBy = By.cssSelector("#app-scrollbar-drawer > div.os-padding > div > div > div > div > div > div:nth-child(1) > div.el-col.el-col-16 > div.mt-2.u-display-flex.u-align-items-center");

    private final By saveButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > div:nth-child(3) > div._authority-matrix > div > div > div > section > div._app-drawer__footer.u-py-3.u-px-4 > button.el-button.el-button--primary._button");

    private final By submitButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > div._footer.u-mt-4 > button.el-button.u-ml-2.el-button--primary._button");
    public AuthorityMatrix(WebDriver driver) {
        this.driver = driver;
        Wait.waitForPageToLoad(driver,searchUserBy);
    }
    public void clickOnNewRule(){
        driver.findElement(newRuleBy).click();
        Wait.waitForDrawer(driver, productBy);
    }
    public void AddProduct(String all){
    driver.findElement(productBy).click();
    driver.findElement(inputProductBy).sendKeys(all + Keys.ENTER);
    }
    public void addConditionForProduct(String condition){
        driver.findElement(conditionBy).click();
        driver.findElement(inputConditionBy).sendKeys(condition + Keys.ENTER);
    }
    public void addAmount(String amount){
        driver.findElement(inputAmountBy).clear();
        driver.findElement(inputAmountBy).sendKeys(amount + Keys.ENTER);
    }

    public void addAuthoriser(){
        driver.findElement(authoriserBy).click();
        Wait.waitForDrawer(driver, authoriserDropdownBy);
        driver.findElement(authoriserDropdownBy).click();
    }

    public void clickOnPreview(){
        driver.findElement(previewBy).click();
    }
    public void clickOnSave(){
        Wait.waitForPageToLoad(driver, productPreviewBy);
        driver.findElement(saveButtonBy).click();
        Wait.waitForSpinner(driver, saveButtonBy);
    }

    public void clickOnSubmit(){
        driver.findElement(submitButtonBy).click();
    }
}
