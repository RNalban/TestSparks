package ae.zand.devops.corporate.UAM;

import ae.zand.devops.Setup;
import ae.zand.devops.constants.Paths;
import ae.zand.devops.views.UAM.*;
import ae.zand.devops.views.common.Login;
import org.testng.annotations.Test;

public class UAMTest extends Setup {
    @Test
    public void creatingNewUser() {
        Login login =  new Login(driver);
        UserManagement userAccessManagement= login.loginAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
        userAccessManagement.clickOnAddRequests();
         AddEditNewUser addEditNewUser = userAccessManagement.clickOnAddNewUser();
        addEditNewUser.enterUserType("Releaser");
        addEditNewUser.setInputPerTransactionLimitBy("9999999");
        addEditNewUser.enterEmail("stacy@email.com");
        addEditNewUser.uploadEIDFront(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/KhoulaID.jpg");
        addEditNewUser.uploadEIDBack(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/KhoulaID.jpg");
        addEditNewUser.enterCountry("United Arab Emirates");
        addEditNewUser.enterMobile("+971501234567");
        addEditNewUser.setGender();
        addEditNewUser.enterUserGroup("Primary Releaser Group");
        addEditNewUser.clickOnPreview();
        addEditNewUser.clickOnNext();
        addEditNewUser.addPermissionsForCreatedUser();
        driver.get(Paths.LOGOUT);
    }
    @Test (dependsOnMethods = {"creatingNewUser"})
    public void editingCreatedUser()  {
        Login login =  new Login(driver);
        UserManagement userManagement = login.loginAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
        AdminRequests adminRequests = userManagement.goToAdminRequests();
        adminRequests.clickOnOptions();
        AddEditNewUser addEditNewUser=adminRequests.clickOnViewEditDetails();
        addEditNewUser.enterMobile("+971501234569");
        addEditNewUser.clickOnPreview();
        addEditNewUser.clickOnNext();
        addEditNewUser.saveChangesForCreatedUser();
        driver.get(Paths.LOGOUT);

    }
    @Test
    public void creatingUserThroughOpsMaker(){
        Login login = new Login(driver);
        OpsPage opsPage = login.loginOpsUser(OPSMAKER_USERNAME, OPSMAKER_PASSWORD);
        opsPage.goToUserManagement();
        opsPage.clickOnNewUser();
        opsPage.enterCIF("000318646");
         AddEditNewUser addEditNewUser = opsPage.clickOnQuickAddNewUser();

        addEditNewUser.setIDType("Emirates ID");
        addEditNewUser.uploadEIDFront(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/KhoulaID.jpg");
        addEditNewUser.uploadEIDBack(System.getProperty("user.dir") + "/src/test/resources/onboarding-documents/KhoulaID.jpg");
        addEditNewUser.enterCountry("United Arab Emirates");
        addEditNewUser.enterMobile("+971501234567");
        addEditNewUser.setGender();
        addEditNewUser.setAdminAccessBy();
        addEditNewUser.setInputDailyApprovalLimitBy("9999999");
        addEditNewUser.setInputDailyDrawDownLimit("9999999");
        addEditNewUser.setInputPerTransactionLimitBy("9999999");
        addEditNewUser.clickOnPreview();
        OpsPage backToOpsPage = addEditNewUser.clickOnSave();
        backToOpsPage.clickOnNext();
        driver.get(Paths.LOGOUT);
    }
    @Test (dependsOnMethods = {"creatingUserThroughOpsMaker"})
    public void addingRuleForUserThroughOpsMaker(){
        Login login = new Login(driver);
        OpsPage opsPage = login.loginOpsUser(OPSMAKER_USERNAME, OPSMAKER_PASSWORD);
        opsPage.goToUserManagement();
        opsPage.viewDetails();
        opsPage.waitForTableToLoad();
        AuthorityMatrix authorityMatrix=opsPage.clickOnNext();
        authorityMatrix.clickOnNewRule();
        authorityMatrix.AddProduct("All");
        authorityMatrix.addConditionForProduct("Greater than or equal");
        authorityMatrix.addAmount("1");
        authorityMatrix.addAuthoriser();
        authorityMatrix.clickOnPreview();
        authorityMatrix.clickOnSave();
        //authorityMatrix.clickOnSubmit();

    }
    @Test (dependsOnMethods = {"addingRuleForUserThroughOpsMaker"})
    public void approveCreatedUserThroughOpsChecker(){
        Login login = new Login(driver);
        OpsPage opsPage = login.loginOpsUser(OPSCHECKER_USERNAME, OPSCHECKER_PASSWORD);
        opsPage.goToUserManagement();
        opsPage.viewDetails();
        opsPage.clickOnNext();
        opsPage.clickOnApprove();
        driver.get(Paths.LOGOUT);
    }



}
