package ae.zand.devops.views.UAM;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AddEditNewUser  {
    protected final WebDriver driver;
    private final By spinnerBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > div.el-loading-mask");
    private final By inputEmailBy = By.cssSelector("input#email");
    private final By userTypeTagBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(1) > span:nth-child(2) > div > div > div > div > div.multiselect__tags");
    private final By inputUserType = By.cssSelector("input#userType");
    private final By inputMobileBy = By.cssSelector("input#phoneNumber");
    private final By inputCountryBy = By.cssSelector("input#nationality");
    private final By countryTagBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(1) > span:nth-child(5) > div > div > div > div > div.multiselect__tags");
    private final By genderBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(1) > span:nth-child(6) > div > div > div > div > label:nth-child(2) > span.el-radio__input > span");
    private final By userGroupBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(1) > span:nth-child(8) > div > div > div > div > div.multiselect__tags");
    private final By inputUserGroupBy = By.cssSelector("input#userGroups");

    private final By idType = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(2) > span:nth-child(1) > div > div > div > div > div.multiselect__tags");
    private final By inputIDType = By.cssSelector("input#identificationProofType");
    private final By inputEmiratesBack = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(2) > span:nth-child(5) > div > div > div > div > div.u-w-100._uploader__container > div > div > input");
    private final By EIDspinnerBack = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(2) > span:nth-child(5) > div > div > div > div > div.el-dialog__wrapper.ocr-loader-dialog > div > div.el-dialog__body > div > div > div.el-progress.el-progress--line.el-progress--without-text > div > div");
    private final By emiratesIDLoadPercentBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(2) > span:nth-child(5) > div > div > div > div > div.el-dialog__wrapper.ocr-loader-dialog > div > div.el-dialog__body > div > div > div.el-progress.el-progress--line.el-progress--without-text > div > div > div");//By.xpath("//span[text()='100%']");
    private final By emiratesFrontBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(2) > span:nth-child(4) > div > div > div > div > div.u-w-100._uploader__container > div > div > div");
    private final By inputEmiratesFront = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(2) > span:nth-child(4) > div > div > div > div > div.u-w-100._uploader__container > div > div > input");
    private final By EIDspinnerFront = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(2) > span:nth-child(4) > div > div > div > div > div > div.el-loading-mask > div ");
    private final By adminAccessBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(1) > span:nth-child(9) > div > div > div > div > label:nth-child(1) > span.el-radio__input > span");
    private final By inputDailyApprovalLimitBy = By.cssSelector("input#dailyApprovalLimit");
    private final By inputDailyDrawDownLimit = By.cssSelector("input#dailyDrawdownLimit");
    private final By inputPerTransactionLimitBy = By.cssSelector("input#perTransactionLimit");

    private final By previewButtonBy= By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-mt-4 > button ");
    private final By iconBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > div._user-form__preview.u-p-4.u-shape-card > div > div.u-display-flex.u-align-items-center.u-mb-4 > span");
    private final By nextButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-mt-4 > button.el-button.u-ml-2.el-button--primary._button");
    private final By allOptionsBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > div:nth-child(1) > div._card.u-mt-3 > div > div > div._uam-permissions-all > span > label > label > span > span");
    private final By createUserBy = By.xpath("//span[text()=' Create user ']");
    private final By saveButtonBy  = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._footer.u-mt-4 > button.el-button.u-ml-2.el-button--primary._button > span");

    public AddEditNewUser(WebDriver driver) {
        this.driver = driver;
        //Wait.waitForSpinner(driver, spinnerBy);
        Wait.waitForPageToLoad(driver,previewButtonBy);
    }
    public void waitForSpinner(){
        Wait.waitForSpinner(driver, spinnerBy);
    }
    public void enterEmail(String email){
        driver.findElement(inputEmailBy).sendKeys(email + Keys.RETURN);
    }

    public void enterUserType(String userType){
        driver.findElement(userTypeTagBy).click();
        driver.findElement(inputUserType).sendKeys(userType + Keys.ENTER);
    }

    public void enterUserGroup(String userType){
        driver.findElement(userGroupBy).click();
        driver.findElement(inputUserGroupBy).sendKeys(userType + Keys.ENTER);
    }

    public void enterMobile(String mobile){
        driver.findElement(inputMobileBy).clear();
        driver.findElement(inputMobileBy).sendKeys(mobile + Keys.ENTER);
    }

    public void enterCountry(String country){
        Wait.waitForSpinner(driver, emiratesIDLoadPercentBy);
        Wait.waitForDrawer(driver, countryTagBy);
        driver.findElement(countryTagBy).click();
        driver.findElement(inputCountryBy).sendKeys(country + Keys.RETURN);
    }

    public void setGender(){

        driver.findElement(genderBy).click();
    }
    public void setAdminAccessBy(){
        driver.findElement(adminAccessBy).click();
    }

    public void setInputPerTransactionLimitBy(String transaction){
        driver.findElement(inputPerTransactionLimitBy).clear();
        driver.findElement(inputPerTransactionLimitBy).sendKeys(transaction + Keys.ENTER);
    }
    public void setInputDailyApprovalLimitBy(String approval){
        driver.findElement(inputDailyApprovalLimitBy).clear();
        driver.findElement(inputDailyApprovalLimitBy).sendKeys(approval +Keys.RETURN);
    }
    public void setInputDailyDrawDownLimit(String dailyDrawDownLimit){
        driver.findElement(inputDailyDrawDownLimit).clear();
        driver.findElement(inputDailyDrawDownLimit).sendKeys(dailyDrawDownLimit + Keys.RETURN);
    }
    public void setIDType(String idProof){
        Wait.waitForSpinner(driver, spinnerBy);
        driver.findElement(idType).click();
        driver.findElement(inputIDType).sendKeys(idProof +Keys.RETURN);
    }
    public void uploadEIDFront(String emiratesID){
        Wait.waitForPageToLoad(driver, emiratesFrontBy);
        driver.findElement(inputEmiratesFront).sendKeys(emiratesID);
        Wait.waitForSpinner(driver, EIDspinnerFront);
    }

    public void uploadEIDBack(String emiratesID){
        driver.findElement(inputEmiratesBack).sendKeys(emiratesID);
        Wait.waitForPageToLoad(driver,EIDspinnerBack);
        Wait.waitForSpinner(driver, EIDspinnerBack);
        Wait.waitForPageToLoad(driver, emiratesIDLoadPercentBy);
    }

    public void clickOnPreview(){
        driver.findElement(previewButtonBy).click();
        Wait.waitForPageToLoad(driver, iconBy);
    }

    public void clickOnNext(){
        Wait.waitForPageToLoad(driver, nextButtonBy);
        driver.findElement(nextButtonBy).click();

    }


    public void addPermissionsForCreatedUser(){
        Wait.waitForPageToLoad(driver, createUserBy);
        driver.findElement(createUserBy).click();
    }

    public void saveChangesForCreatedUser(){
        Wait.waitForPageToLoad(driver, saveButtonBy);
        driver.findElement(saveButtonBy).click();
    }

    public OpsPage clickOnSave(){
        Wait.waitForPageToLoad(driver, nextButtonBy);
        driver.findElement(nextButtonBy).click();
        return new OpsPage(driver);
    }
}
