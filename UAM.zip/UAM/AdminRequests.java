package ae.zand.devops.views.UAM;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class AdminRequests {
    protected final WebDriver driver;
    private final  By viewOptionsBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/section/div[1]/div[4]/div[2]/table/tbody/tr[1]/td[5]/div/span/div[2]/button");
    private final By viewEditOptionBy = By.xpath("(//*[text()=' View/Edit '])[2]");

    private final By statusBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > section > div> div > div.multiselect__tags");
    private final By optionBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/section/div[1]/div[2]/section/div/div[4]/div[2]/table/tbody/tr[1]/td[5]/div/span/div[2]/button");
    private final By viewEditUser = By.cssSelector("body > ul > li:nth-child(1)"); //("(//*[text()=' View / Edit '])[16]");

    public AdminRequests(WebDriver driver) {
        this.driver = driver;
        Wait.waitForPageToLoad(driver, statusBy);

    }
    public void clickOnOptions(){
        Wait.waitForPageToLoad(driver, viewOptionsBy);
        driver.findElement(viewOptionsBy).click();
        Wait.waitForDrawer(driver,viewEditOptionBy);
        driver.findElement(viewEditOptionBy).click();

    }
    public AddEditNewUser clickOnViewEditDetails(){
        Wait.waitForPageToLoad(driver, optionBy);
        driver.findElement(optionBy).click();
        Wait.waitForPageToLoad(driver, viewEditUser);
        driver.findElement(viewEditUser).click();
        return new AddEditNewUser(driver);

    }
}
