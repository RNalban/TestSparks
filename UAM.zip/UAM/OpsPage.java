package ae.zand.devops.views.UAM;

import ae.zand.devops.utils.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class OpsPage {
    protected final WebDriver driver;
    private final By newUserBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > section > div.o-heading__right.el-row > button");
    private final By userManageBy = By.cssSelector(" div:nth-child(4) > a > li > div > div.app-sidemenu__item__title > span");
    private final By cifBy = By.cssSelector("input#cif");
    private final By createButtonBy = By.cssSelector("body > div.el-drawer__wrapper._drawer-uam > div > div > section > div._app-drawer__footer.u-py-3.u-px-4 > div > button.el-button.el-button--primary._button");
    private final By addNewUserBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > section > div.o-heading__right.el-row > div > button");
    private final By quickAddBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > section > div > div > div > div.multiselect__tags");
    private final By quickAddOptionBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > section > div > div > div > div.multiselect__content-wrapper > ul > li.multiselect__element > span > span");
   private final By optionBy = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/section/section/div[2]/div[4]/div[2]/table/tbody/tr[1]/td[6]/div/span/div[2]/button");
    private final By viewEditDetailsBy = By.cssSelector("body > ul > li:nth-child(1)");
    private final By nextButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > div._footer.u-mt-2 > div > button.el-button.u-ml-2.el-button--primary._button");
    private final By approveButtonBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > div._footer.u-mt-4 > button.el-button.u-ml-2.el-button--primary._button");
    private final By tableLoadingMask = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > div:nth-child(3) > div > section > div > div.el-table__body-wrapper.is-scrolling-none > table > tbody > tr");
    public OpsPage(WebDriver driver) {
        this.driver = driver;
       // Wait.waitForSpinner(driver, spinnerBy);
    }

    public void goToUserManagement(){
        driver.findElement(userManageBy).click();
        //Wait.waitForPageToLoad(driver, newUserBy);
        //driver.findElement(newUserBy).click();
    }
    public void clickOnNewUser(){
        Wait.waitForPageToLoad(driver, newUserBy);
        driver.findElement(newUserBy).click();
    }
    public void enterCIF(String clientID){
        Wait.waitForPageToLoad(driver, cifBy);
        driver.findElement(cifBy).sendKeys(clientID + Keys.ENTER);
        driver.findElement(createButtonBy).click();
    }
    public AddEditNewUser clickOnQuickAddNewUser(){
        Wait.waitForPageToLoad(driver, quickAddBy);
        driver.findElement(quickAddBy).click();
        Wait.waitForPageToLoad(driver, quickAddOptionBy);
       driver.findElement(quickAddOptionBy).click();
        return new AddEditNewUser(driver);
    }
    public void viewDetails(){
        Wait.waitForPageToLoad(driver, optionBy);
        driver.findElement(optionBy).click();
        Wait.waitForPageToLoad(driver, viewEditDetailsBy);
        driver.findElement(viewEditDetailsBy).click();
    }
    public void waitForTableToLoad(){
     Wait.waitForPageToLoad(driver, tableLoadingMask);
    }
    public AuthorityMatrix clickOnNext(){
        Wait.waitForPageToLoad(driver, nextButtonBy);
        driver.findElement(nextButtonBy).click();
        Wait.waitForSpinner(driver, nextButtonBy);
            return new AuthorityMatrix(driver);
    }

    public void clickOnApprove(){
        Wait.waitForPageToLoad(driver, approveButtonBy);
        driver.findElement(approveButtonBy).click();
    }

}
