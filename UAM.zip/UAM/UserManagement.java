package ae.zand.devops.views.UAM;

import ae.zand.devops.utils.Wait;
import net.bytebuddy.asm.Advice;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class UserManagement {
    protected final WebDriver driver;
    private final By addNewRequestsBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > section > section > div.o-heading__right.el-row > button");
    private final By addNewUserBy = By.xpath("//span[text()=' New user ']");
    private final By userTypeTagBy = By.cssSelector("#app > div.app-wrapper.openSidebar.withoutAnimation > div.main-container > div:nth-child(2) > section > span > section > div._user-form > form > div > div:nth-child(1) > span:nth-child(2) > div > div > div > div > div.multiselect__tags");
    private final By adminRequestsBy = By.cssSelector("#app-scrollbar-app-sidemenu__wrapper > div.os-padding > div > div > ul > div:nth-child(3) > li > ul > div:nth-child(1) > a > li > div > div > span");
    public UserManagement(WebDriver driver) {
        this.driver = driver;
        Wait.waitForPageToLoad(driver, addNewRequestsBy);
    }
    public void clickOnAddRequests(){
        driver.findElement(addNewRequestsBy).click();

    }
    public AddEditNewUser clickOnAddNewUser(){

        Wait.waitForPageToLoad(driver, addNewUserBy);
        driver.findElement(addNewUserBy).click();

        Wait.waitForPageToLoad(driver, userTypeTagBy);
        return new AddEditNewUser(driver);

    }
    public AdminRequests goToAdminRequests(){
        driver.findElement(adminRequestsBy).click();
        return new AdminRequests(driver);
    }
}
